# Security Specification — A Little World Made For You ♡

## 1. Master Relationship Mapping
- **Bootstrapped & Trusted Admin (`/admins/{userId}`)**:
  - Primary admin is strictly `oktafmbul0@gmail.com` (`email_verified == true`), verified either directly by verified email match or `/admins/{request.auth.uid}` existence.
  - Users cannot self-assign admin status in any collection.
- **Couple Authorization Config (`/config/access`)**:
  - Holds `adminEmail`, `oktafEmail`, `wulanEmail`, and `wishlistPrivacyMode`.
  - Readable ONLY by `isAdmin()` or the verified email configured in `resource.data.wulanEmail`. Never readable by public/anonymous visitors (PII protection).
  - Mutable ONLY by `isAdmin()`.
- **Public Content Partition (`/siteContent/{sectionId}`)**:
  - Partitioned to fixed keys `story`, `world`, `letters`, `video`, `miniOktaf`, `vinyl` so every doc stays well under Firestore's 1MB limit.
  - Public visitors can `get` individual sections; `list` is restricted to `isAdmin()`.
  - Only `isAdmin()` can `create` / `update` / `delete`.
- **Voices of Love (`/voices/{voiceId}`)**:
  - Individual friend recordings referencing Firebase Storage URLs.
  - Public `get` / `list` is strictly scoped via `resource.data.permissionConfirmed == true || isAdmin()`.
  - Writes strictly require `isAdmin()`, valid schema, `ownerUid == request.auth.uid`, and `request.time` timestamps.
- **Vinyl Playlist (`/vinylPlaylist/{trackId}`)**:
  - Public `get` / `list` scoped via `resource.data.isPublished == true || isAdmin()`.
  - Writes strictly require `isAdmin()`, 11-character `youtubeVideoId` regex match, and `request.time` timestamps.
- **Media Assets Index (`/mediaAssets/{assetId}`)**:
  - Strictly `isAdmin()` read/write (`get`, `list`, `create`, `update`, `delete`).
- **Private Collaborative Wishlist (`/wishlist/{wishId}`)**:
  - Strictly **private to Oktaf and Wulan**. Public visitors and third-party Google accounts receive `PERMISSION_DENIED`.
  - Every `list` query evaluates `resource.data` directly (no `get()`/`exists()` inside `allow list`): caller must be verified and either `oktafEmail` (`oktafmbul0@gmail.com`) or listed inside `resource.data.allowedEmails` (bounded `.size() <= 4`).
  - `get` verifies `isAdmin() || isAuthorizedCoupleMemberOnDoc()`.
  - `create` requires `isAuthorizedCoupleMember()` (verifying `config/access` when non-admin), `creatorUid == request.auth.uid`, `creatorEmail == lowerEmail()`, `createdAt == request.time`, `updatedAt == request.time`, `visibility == 'couple'`, `photos.size() <= 6`, `allowedEmails.size() <= 4`.
  - `update` splits into explicit Action branches:
    1. `isAdmin()` full moderation/correction action (with `isValidWishlistEntry` + immutable `createdAt`, `creatorUid`, `id`).
    2. Couple edit action (`isAuthorizedCoupleMember()`, allowed ONLY when `existing().status != 'completed'` and either `existing().creatorUid == request.auth.uid` or `existing().category == 'our'`, updating only whitelisted mutable fields `['title', 'description', 'category', 'targetDate', 'status', 'photos', 'completionStory', 'completedAt', 'updatedAt']`).
    3. Completion memory addition action (when `existing().status == 'completed'`, non-admin couple creator/shared partner may ONLY add/update `['photos', 'completionStory', 'updatedAt']`, locking terminal `status`, `category`, `creatorUid`, `createdAt`, `visibility`).

## 2. Data Invariants
1. Public visitors never see `config/access`, `admins`, `mediaAssets`, or `wishlist`.
2. Unverified tokens (`email_verified != true`) are rejected from ALL mutations and ALL private reads.
3. No document ID exceeding 128 chars or containing non-`[a-zA-Z0-9_-]` characters can be written.
4. No arbitrary client-forged timestamps (`createdAt`/`updatedAt`) are accepted — `request.time` is strictly enforced.
5. `photos` and `allowedEmails` arrays on `/wishlist/{wishId}` are strictly bounded (`<= 6` and `<= 4`), and every string field enforces explicit `.size()` bounds matching `firebase-blueprint.json`.
6. Once a wishlist item reaches terminal status `completed`, non-admin updates cannot regress `status` back to `dreaming`/`planned`/`in_progress` or alter `creatorUid`/`createdAt`/`category`.

## 3. "Dirty Dozen" Attack Payloads (Expected: PERMISSION_DENIED)
1. **Unauthenticated Wishlist Read**: Anonymous visitor runs `get` or `list` on `/wishlist`.
2. **Third-Party Account Snooping**: Verified `stranger@gmail.com` queries `list` on `/wishlist` or `get` on `/config/access`.
3. **Email Spoofing (Unverified Email)**: Token claims `email: "oktafmbul0@gmail.com"` with `email_verified: false` attempting admin write on `/siteContent/story`.
4. **Admin Self-Escalation**: Non-admin user attempts `create` on `/admins/{theirUid}` with `{ role: "admin" }`.
5. **Shadow / Ghost Field Injection**: Authorized couple member creates `/wishlist/w1` with extra `{ isAdminOverride: true }` field.
6. **Creator Identity Spoofing**: Wulan attempts to create `/wishlist/w2` with `creatorUid: "oktaf-uid-123"`.
7. **Timestamp Forgery**: Authenticated admin creates `/voices/v1` with backdated `createdAt: "2020-01-01T00:00:00Z"` instead of `request.time`.
8. **ID Poisoning**: Admin tries writing `/voices/bad..id!!` or a 300-character document ID.
9. **Resource Exhaustion / Array Overflow**: User attaches 20 items in `/wishlist/w3.photos` or >3000 chars in `completionStory`.
10. **Unauthorized Personal Wish Edit**: Wulan tries to edit Oktaf's private `'your'` wishlist item (`category: 'your'`).
11. **Terminal State Regression**: Non-admin tries to revert a `'completed'` wish back to `'dreaming'` in `/wishlist/{wishId}`.
12. **Unpublished Voice Leak**: Public visitor queries `/voices` where `permissionConfirmed: false`.
