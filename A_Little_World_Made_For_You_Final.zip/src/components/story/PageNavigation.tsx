import { useState } from 'react';
import { BookMarked, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { MemoryBookPage } from '../../data/memories';
import {
  BookSpreadPair,
  getReadingProgressPercent,
  getSpreadPageIndicator,
  TOTAL_MEMORY_PAGES,
} from '../../utils/memoryBook';

interface PageNavigationProps {
  spreadIndex: number;
  spreads: BookSpreadPair<MemoryBookPage>[];
  onPrev: () => void;
  onNext: () => void;
  onJumpToSpread: (index: number) => void;
  onCloseBook: () => void;
}

export function PageNavigation({
  spreadIndex,
  spreads,
  onPrev,
  onNext,
  onJumpToSpread,
  onCloseBook,
}: PageNavigationProps) {
  const [indexOpen, setIndexOpen] = useState(false);

  const pageLabel = getSpreadPageIndicator(spreadIndex, TOTAL_MEMORY_PAGES);
  const progressPercent = getReadingProgressPercent(spreadIndex, TOTAL_MEMORY_PAGES);
  const currentSpread = spreads[spreadIndex];
  const spreadTheme = currentSpread?.leftPage?.spreadTheme ?? `Spread ${spreadIndex + 1}`;

  return (
    <div className="relative w-full max-w-[720px] mx-auto px-2 sm:px-4 mt-3">
      <div className="bg-[#FBF6EE]/95 border border-[#38271F]/14 rounded-2xl px-3 py-2 sm:px-4 sm:py-2.5 shadow-xs">
        <div className="flex flex-wrap sm:flex-nowrap items-center justify-between gap-2">
          {/* Close Book & Return to Cover */}
          <button
            type="button"
            onClick={onCloseBook}
            className="min-h-[40px] sm:min-h-[42px] px-2.5 sm:px-3 py-1.5 rounded-xl border border-[#38271F]/18 text-xs font-medium text-[#38271F] hover:bg-[#EAE0CF] transition-colors inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
          >
            <X className="w-3.5 h-3.5" />
            <span>Tutup Buku</span>
          </button>

          {/* Center Page Indicator & Optional Page Index Toggle */}
          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
            <div className="text-center min-w-0">
              <p className="text-xs sm:text-sm font-serif font-semibold text-[#38271F] tabular-nums whitespace-nowrap">
                {pageLabel}
              </p>
              <p className="text-[10px] sm:text-[11px] text-[#743D4A] truncate">{spreadTheme}</p>
            </div>

            <button
              type="button"
              onClick={() => setIndexOpen((v) => !v)}
              aria-expanded={indexOpen}
              aria-label="Daftar halaman buku"
              className={`min-h-[40px] px-2.5 py-1.5 rounded-xl border text-xs font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
                indexOpen
                  ? 'bg-[#455342] text-[#F4EBDD] border-[#455342]'
                  : 'bg-[#F4EBDD] text-[#38271F] border-[#38271F]/16 hover:bg-[#EAE0CF]'
              }`}
            >
              <BookMarked className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Daftar Isi</span>
            </button>
          </div>

          {/* Previous / Next Spread Controls */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={onPrev}
              disabled={spreadIndex <= 0}
              aria-label="Halaman sebelumnya"
              className="min-w-[42px] min-h-[42px] px-2.5 py-1.5 rounded-xl border border-[#38271F]/18 bg-[#FBF6EE] text-xs font-medium text-[#38271F] hover:bg-[#EAE0CF] disabled:opacity-35 disabled:pointer-events-none inline-flex items-center justify-center gap-1 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
              <span className="hidden md:inline">Sebelumnya</span>
            </button>

            <button
              type="button"
              onClick={onNext}
              disabled={spreadIndex >= spreads.length - 1}
              aria-label="Halaman berikutnya"
              className="min-w-[42px] min-h-[42px] px-2.5 py-1.5 rounded-xl bg-[#38271F] text-[#F4EBDD] text-xs font-medium hover:bg-[#4e382d] disabled:opacity-35 disabled:pointer-events-none inline-flex items-center justify-center gap-1 cursor-pointer"
            >
              <span className="hidden md:inline">Berikutnya</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Reading Progress Bar */}
        <div className="mt-2.5 flex items-center gap-3">
          <div
            role="progressbar"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={progressPercent}
            aria-label="Progres membaca Memory Book"
            className="flex-1 h-1.5 rounded-full bg-[#38271F]/10 overflow-hidden"
          >
            <div
              className="h-full bg-[#A6533B] transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <span className="text-[11px] font-medium text-[#38271F]/65 tabular-nums whitespace-nowrap">
            {progressPercent}%
          </span>
        </div>
      </div>

      {/* Quick Spread Index Selector Drawer */}
      {indexOpen && (
        <div className="mt-2 bg-[#FBF6EE] border border-[#38271F]/18 rounded-2xl p-3 sm:p-4 shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold text-[#38271F]">
              Lompat ke Bagian Buku (9 Spread · 17 Halaman)
            </p>
            <button
              type="button"
              onClick={() => setIndexOpen(false)}
              aria-label="Tutup daftar halaman"
              className="text-xs text-[#743D4A] hover:underline cursor-pointer"
            >
              Tutup
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5">
            {spreads.map((sp) => {
              const active = sp.spreadIndex === spreadIndex;
              const pLeft = sp.leftPage?.pageNumber;
              const pRight = sp.rightPage?.pageNumber;
              const numLabel = pRight ? `Hal. ${pLeft}–${pRight}` : `Hal. ${pLeft}`;
              return (
                <button
                  key={sp.spreadIndex}
                  type="button"
                  onClick={() => {
                    onJumpToSpread(sp.spreadIndex);
                    setIndexOpen(false);
                  }}
                  className={`min-h-[42px] px-3 py-2 rounded-xl text-left text-xs transition-colors flex items-center justify-between gap-2 cursor-pointer ${
                    active
                      ? 'bg-[#38271F] text-[#F4EBDD]'
                      : 'bg-[#F4EBDD]/70 text-[#38271F] hover:bg-[#EAE0CF]'
                  }`}
                >
                  <span className="truncate font-medium">
                    {sp.leftPage?.spreadTheme ?? `Spread ${sp.spreadNumber}`}
                  </span>
                  <span className="text-[10px] opacity-75 tabular-nums shrink-0">{numLabel}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
