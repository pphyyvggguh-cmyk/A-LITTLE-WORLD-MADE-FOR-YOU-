import { useCallback, useEffect, useMemo, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { HiddenEnvelopeMessage } from '../../data/hiddenMessages';
import { BookPolaroidItem } from '../../data/memories';
import { useContentStore } from '../../store/useContentStore';
import {
  buildBookSpreads,
  clampSpreadIndex,
  loadSessionSpreadIndex,
  saveSessionSpreadIndex,
} from '../../utils/memoryBook';
import { EASE_OUT_EXPO } from '../../utils/animation';
import { BookCover } from './BookCover';
import { BookSpread } from './BookSpread';
import { HiddenEnvelopeModal } from './HiddenEnvelope';
import { PageNavigation } from './PageNavigation';
import { PhotoModal } from './PhotoModal';

interface MemoryBookProps {
  onFirstBookInteraction: () => void;
}

export function MemoryBook({ onFirstBookInteraction }: MemoryBookProps) {
  const prefersReducedMotion = useReducedMotion();
  const storyPages = useContentStore((s) => s.storyPages);

  const spreads = useMemo(() => buildBookSpreads(storyPages), [storyPages]);

  const [isBookOpen, setIsBookOpen] = useState(false);
  const [spreadIndex, setSpreadIndex] = useState<number>(() => loadSessionSpreadIndex());
  const [turnDirection, setTurnDirection] = useState<1 | -1>(1);

  const [activePhoto, setActivePhoto] = useState<{
    item: BookPolaroidItem;
    pageLabel: string;
  } | null>(null);
  const [activeEnvelope, setActiveEnvelope] = useState<HiddenEnvelopeMessage | null>(null);

  const goToSpread = useCallback(
    (nextIndex: number) => {
      const clamped = clampSpreadIndex(nextIndex, spreads.length);
      setSpreadIndex((prev) => {
        setTurnDirection(clamped >= prev ? 1 : -1);
        saveSessionSpreadIndex(clamped);
        return clamped;
      });
    },
    [spreads.length]
  );

  const handleOpenBook = () => {
    onFirstBookInteraction();
    setIsBookOpen(true);
  };

  const handleCloseBook = () => {
    setActivePhoto(null);
    setActiveEnvelope(null);
    saveSessionSpreadIndex(spreadIndex);
    setIsBookOpen(false);
  };

  const handleNextSpread = useCallback(() => {
    if (spreadIndex < spreads.length - 1) {
      goToSpread(spreadIndex + 1);
    }
  }, [spreadIndex, spreads.length, goToSpread]);

  const handlePrevSpread = useCallback(() => {
    if (spreadIndex > 0) {
      goToSpread(spreadIndex - 1);
    }
  }, [spreadIndex, goToSpread]);

  useEffect(() => {
    if (!isBookOpen || activePhoto || activeEnvelope) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') {
        handleNextSpread();
      } else if (e.key === 'ArrowLeft') {
        handlePrevSpread();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isBookOpen, activePhoto, activeEnvelope, handleNextSpread, handlePrevSpread]);

  const currentSpread = spreads[spreadIndex] ?? spreads[0];

  return (
    <div className="w-full">
      {!isBookOpen ? (
        <BookCover
          onOpen={handleOpenBook}
          hasSavedSessionSpread={spreadIndex > 0}
        />
      ) : (
        <motion.div
          key="open-memory-book"
          initial={prefersReducedMotion ? { opacity: 1 } : { opacity: 0, scale: 0.96, y: 14 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.42, ease: EASE_OUT_EXPO }}
          className="w-full"
        >
          <BookSpread
            spread={currentSpread}
            direction={turnDirection}
            onNextSpread={handleNextSpread}
            onPrevSpread={handlePrevSpread}
            onSelectPolaroid={(item, pageLabel) => setActivePhoto({ item, pageLabel })}
            onOpenEnvelope={(msg) => setActiveEnvelope(msg)}
            onReturnToCover={handleCloseBook}
          />

          <PageNavigation
            spreadIndex={spreadIndex}
            spreads={spreads}
            onPrev={handlePrevSpread}
            onNext={handleNextSpread}
            onJumpToSpread={goToSpread}
            onCloseBook={handleCloseBook}
          />
        </motion.div>
      )}

      {/* Expanded Photograph Modal */}
      <PhotoModal
        polaroid={activePhoto?.item ?? null}
        pageLabel={activePhoto?.pageLabel}
        onClose={() => setActivePhoto(null)}
      />

      {/* Hidden Paper Envelope Message Modal */}
      <HiddenEnvelopeModal
        envelope={activeEnvelope}
        onClose={() => setActiveEnvelope(null)}
      />
    </div>
  );
}
