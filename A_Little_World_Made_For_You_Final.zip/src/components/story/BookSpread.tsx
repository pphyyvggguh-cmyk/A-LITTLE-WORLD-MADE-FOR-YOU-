import { useEffect, useRef } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { HiddenEnvelopeMessage } from '../../data/hiddenMessages';
import { BookPolaroidItem, MemoryBookPage } from '../../data/memories';
import { BookSpreadPair, detectSwipeDirection } from '../../utils/memoryBook';
import { BookPage, ClosingBookPage } from './BookPage';

interface BookSpreadProps {
  spread: BookSpreadPair<MemoryBookPage>;
  direction: 1 | -1;
  onNextSpread: () => void;
  onPrevSpread: () => void;
  onSelectPolaroid: (item: BookPolaroidItem, pageLabel: string) => void;
  onOpenEnvelope: (msg: HiddenEnvelopeMessage) => void;
  onReturnToCover: () => void;
}

/**
 * Exclude explicit control buttons/inputs/flowers from swipe-start tracking,
 * while allowing horizontal swipes that begin over Polaroids or envelopes
 * (taps still open them, while drags >= 16px turn the page and suppress click).
 */
function isSwipeBlockedTarget(target: EventTarget | null): boolean {
  if (!(target instanceof Element)) return false;
  return Boolean(
    target.closest('[data-no-swipe="true"]') ||
      target.closest('a') ||
      target.closest('input')
  );
}

export function BookSpread({
  spread,
  direction,
  onNextSpread,
  onPrevSpread,
  onSelectPolaroid,
  onOpenEnvelope,
  onReturnToCover,
}: BookSpreadProps) {
  const prefersReducedMotion = useReducedMotion();
  const pointerStartRef = useRef<{ x: number; y: number } | null>(null);
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);
  const lastSwipeTsRef = useRef(0);
  const suppressClickUntilRef = useRef(0);

  const handleDragComplete = (dx: number, dy: number) => {
    if (Math.abs(dx) >= 16) {
      suppressClickUntilRef.current = Date.now() + 260;
    }

    const now = Date.now();
    if (now - lastSwipeTsRef.current < 160) return;

    const swipe = detectSwipeDirection(dx, dy);
    if (swipe === 'next') {
      lastSwipeTsRef.current = now;
      suppressClickUntilRef.current = now + 260;
      onNextSpread();
    } else if (swipe === 'prev') {
      lastSwipeTsRef.current = now;
      suppressClickUntilRef.current = now + 260;
      onPrevSpread();
    }
  };

  // Ensure mouse drags released anywhere over the window complete cleanly
  useEffect(() => {
    const handleWindowPointerUp = (e: PointerEvent) => {
      if (e.pointerType === 'touch' || !pointerStartRef.current) return;
      const dx = e.clientX - pointerStartRef.current.x;
      const dy = e.clientY - pointerStartRef.current.y;
      pointerStartRef.current = null;
      handleDragComplete(dx, dy);
    };

    const handleWindowPointerCancel = () => {
      pointerStartRef.current = null;
    };

    window.addEventListener('pointerup', handleWindowPointerUp);
    window.addEventListener('pointercancel', handleWindowPointerCancel);
    return () => {
      window.removeEventListener('pointerup', handleWindowPointerUp);
      window.removeEventListener('pointercancel', handleWindowPointerCancel);
    };
  });

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'touch') return;
    if (isSwipeBlockedTarget(e.target)) {
      pointerStartRef.current = null;
      return;
    }
    pointerStartRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length !== 1 || isSwipeBlockedTarget(e.target)) {
      touchStartRef.current = null;
      return;
    }
    const touch = e.touches[0];
    touchStartRef.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!touchStartRef.current || e.changedTouches.length === 0) return;
    const touch = e.changedTouches[0];
    const dx = touch.clientX - touchStartRef.current.x;
    const dy = touch.clientY - touchStartRef.current.y;
    touchStartRef.current = null;
    handleDragComplete(dx, dy);
  };

  const handleClickCapture = (e: React.MouseEvent<HTMLDivElement>) => {
    if (Date.now() < suppressClickUntilRef.current) {
      e.stopPropagation();
      e.preventDefault();
    }
  };

  return (
    <div className="w-full max-w-[1000px] mx-auto px-1 sm:px-4">
      {/* Hardcover Open Book Binding Shell */}
      <div
        onPointerDown={handlePointerDown}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        onTouchCancel={() => {
          touchStartRef.current = null;
        }}
        onClickCapture={handleClickCapture}
        className="book-open-binding relative rounded-xl sm:rounded-2xl p-1.5 sm:p-2.5 md:p-3.5 select-none touch-pan-y"
      >
        {/* Outer subtle layered paper edge tabs */}
        <div className="relative bg-[#EDE1CF] rounded-lg sm:rounded-xl p-0.5 sm:p-1 shadow-inner overflow-hidden">
          <AnimatePresence mode="popLayout" initial={false}>
            <motion.div
              key={spread.spreadIndex}
              initial={
                prefersReducedMotion
                  ? { opacity: 0.9 }
                  : {
                      opacity: 0.35,
                      x: direction * 28,
                      scaleX: 0.985,
                    }
              }
              animate={{
                opacity: 1,
                x: 0,
                scaleX: 1,
              }}
              exit={
                prefersReducedMotion
                  ? { opacity: 0 }
                  : {
                      opacity: 0,
                      x: direction * -24,
                      scaleX: 0.985,
                    }
              }
              transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
              className="relative grid grid-cols-2"
            >
              {/* Left Facing Page */}
              {spread.leftPage ? (
                <BookPage
                  page={spread.leftPage}
                  side="left"
                  onSelectPolaroid={onSelectPolaroid}
                  onOpenEnvelope={onOpenEnvelope}
                />
              ) : (
                <div className="min-h-[340px] sm:min-h-[430px] md:min-h-[468px] bg-[#FBF7EF] book-page-left rounded-l-md" />
              )}

              {/* Right Facing Page (or complementary Closing Page on Spread 9) */}
              {spread.rightPage ? (
                <BookPage
                  page={spread.rightPage}
                  side="right"
                  onSelectPolaroid={onSelectPolaroid}
                  onOpenEnvelope={onOpenEnvelope}
                />
              ) : (
                <ClosingBookPage onReturnToCover={onReturnToCover} />
              )}

              {/* Central Book Spine Crease & Depth Shadow */}
              <div
                aria-hidden="true"
                className="book-spine-shadow pointer-events-none absolute inset-y-0 left-1/2 -translate-x-1/2 w-5 sm:w-8 z-30"
              />
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
