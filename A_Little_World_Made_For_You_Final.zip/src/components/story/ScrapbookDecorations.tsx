import { DecorationKind, PageDecoration } from '../../data/memories';

interface DecorationSVGProps {
  kind: DecorationKind;
  className?: string;
  label?: string;
}

export function DecorationSVG({ kind, className = 'w-8 h-8', label }: DecorationSVGProps) {
  switch (kind) {
    case 'daisy':
      return (
        <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
          <g transform="translate(32,32)">
            {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
              <ellipse
                key={deg}
                cx="0"
                cy="-14"
                rx="4.6"
                ry="10"
                transform={`rotate(${deg})`}
                fill="#FBF6EE"
                stroke="#38271F"
                strokeOpacity="0.45"
                strokeWidth="1.2"
              />
            ))}
            <circle cx="0" cy="0" r="6.5" fill="#C4A574" stroke="#38271F" strokeOpacity="0.5" strokeWidth="1.2" />
          </g>
        </svg>
      );

    case 'rose':
      return (
        <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
          <path d="M32 38 C32 48 31 54 29 58" fill="none" stroke="#455342" strokeWidth="2.2" strokeLinecap="round" />
          <path d="M32 46 Q42 42 44 48 Q38 51 32 46 Z" fill="#455342" opacity="0.82" />
          <circle cx="32" cy="25" r="13" fill="#E8BFC5" stroke="#743D4A" strokeWidth="1.4" />
          <path d="M25 25 C25 19 36 18 38 24 C40 30 30 33 27 28 C25 24 31 21 34 24" fill="none" stroke="#743D4A" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );

    case 'wildflower':
      return (
        <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
          <path d="M32 56 Q31 40 33 24" fill="none" stroke="#455342" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M32 42 Q23 36 21 40 Q25 45 32 42 Z" fill="#455342" opacity="0.75" />
          <circle cx="33" cy="18" r="5" fill="#E8BFC5" stroke="#38271F" strokeOpacity="0.4" strokeWidth="1" />
          <circle cx="24" cy="24" r="4" fill="#C4A574" opacity="0.75" />
          <circle cx="42" cy="25" r="4" fill="#E8BFC5" opacity="0.85" />
          <circle cx="33" cy="18" r="2" fill="#743D4A" />
        </svg>
      );

    case 'leaf':
      return (
        <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
          <path
            d="M14 48 C18 24 36 14 52 12 C48 32 36 46 14 48 Z"
            fill="#455342"
            fillOpacity="0.22"
            stroke="#455342"
            strokeWidth="1.8"
          />
          <path d="M12 50 Q30 30 48 15" fill="none" stroke="#455342" strokeWidth="1.4" strokeLinecap="round" />
        </svg>
      );

    case 'branch':
      return (
        <svg viewBox="0 0 72 64" className={className} aria-hidden="true">
          <path d="M10 52 Q30 36 58 14" fill="none" stroke="#38271F" strokeOpacity="0.55" strokeWidth="1.8" strokeLinecap="round" />
          <ellipse cx="26" cy="34" rx="7" ry="3.5" transform="rotate(-35 26 34)" fill="#455342" fillOpacity="0.65" />
          <ellipse cx="42" cy="24" rx="6.5" ry="3" transform="rotate(20 42 24)" fill="#455342" fillOpacity="0.65" />
          <ellipse cx="52" cy="14" rx="5.5" ry="2.8" transform="rotate(-15 52 14)" fill="#455342" fillOpacity="0.7" />
        </svg>
      );

    case 'butterfly':
      return (
        <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
          <path d="M31 24 C20 12 10 18 14 29 C16 35 26 34 31 31" fill="#E8BFC5" stroke="#743D4A" strokeWidth="1.4" />
          <path d="M33 24 C44 12 54 18 50 29 C48 35 38 34 33 31" fill="#E8BFC5" stroke="#743D4A" strokeWidth="1.4" />
          <path d="M31 32 C22 35 16 44 23 48 C28 50 31 42 31 34" fill="#C4A574" fillOpacity="0.65" stroke="#743D4A" strokeWidth="1.3" />
          <path d="M33 32 C42 35 48 44 41 48 C36 50 33 42 33 34" fill="#C4A574" fillOpacity="0.65" stroke="#743D4A" strokeWidth="1.3" />
          <line x1="32" y1="20" x2="32" y2="44" stroke="#38271F" strokeWidth="2.2" strokeLinecap="round" />
          <path d="M31 20 Q27 13 24 14 M33 20 Q37 13 40 14" fill="none" stroke="#38271F" strokeWidth="1.2" strokeLinecap="round" />
        </svg>
      );

    case 'bird':
      return (
        <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
          <path
            d="M16 38 C20 24 34 20 42 26 L52 24 L45 31 C45 41 34 47 22 44 L12 48 Z"
            fill="#C4A574"
            fillOpacity="0.4"
            stroke="#38271F"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
          <circle cx="40" cy="27" r="1.7" fill="#38271F" />
          <path d="M27 33 Q33 28 38 34" fill="none" stroke="#A6533B" strokeWidth="1.4" strokeLinecap="round" />
        </svg>
      );

    case 'bee':
      return (
        <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
          <ellipse cx="28" cy="23" rx="7" ry="4.5" transform="rotate(-25 28 23)" fill="#FBF6EE" stroke="#38271F" strokeOpacity="0.45" strokeWidth="1.2" />
          <ellipse cx="38" cy="23" rx="7" ry="4.5" transform="rotate(25 38 23)" fill="#FBF6EE" stroke="#38271F" strokeOpacity="0.45" strokeWidth="1.2" />
          <ellipse cx="33" cy="35" rx="11" ry="8" fill="#E6B85C" stroke="#38271F" strokeWidth="1.6" />
          <line x1="29" y1="28" x2="29" y2="42" stroke="#38271F" strokeWidth="2.4" />
          <line x1="36" y1="28" x2="36" y2="42" stroke="#38271F" strokeWidth="2.4" />
          <circle cx="40" cy="33" r="1.4" fill="#38271F" />
        </svg>
      );

    case 'cat':
      return (
        <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
          <path
            d="M18 24 L22 14 L29 21 L35 21 L42 14 L46 24 C49 28 49 36 45 41 C41 45 23 45 19 41 C15 36 15 28 18 24 Z"
            fill="#FBF6EE"
            stroke="#38271F"
            strokeWidth="1.7"
            strokeLinejoin="round"
          />
          <circle cx="27" cy="30" r="1.7" fill="#38271F" />
          <circle cx="37" cy="30" r="1.7" fill="#38271F" />
          <path d="M30 34 Q32 36 34 34" fill="none" stroke="#A6533B" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="14" y1="31" x2="21" y2="32" stroke="#38271F" strokeOpacity="0.5" strokeWidth="1.2" />
          <line x1="43" y1="32" x2="50" y2="31" stroke="#38271F" strokeOpacity="0.5" strokeWidth="1.2" />
        </svg>
      );

    case 'rabbit':
      return (
        <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
          <ellipse cx="26" cy="18" rx="4" ry="11" transform="rotate(-8 26 18)" fill="#FBF6EE" stroke="#38271F" strokeWidth="1.5" />
          <ellipse cx="38" cy="18" rx="4" ry="11" transform="rotate(8 38 18)" fill="#FBF6EE" stroke="#38271F" strokeWidth="1.5" />
          <ellipse cx="32" cy="37" rx="13" ry="11" fill="#FBF6EE" stroke="#38271F" strokeWidth="1.6" />
          <circle cx="27" cy="35" r="1.6" fill="#38271F" />
          <circle cx="37" cy="35" r="1.6" fill="#38271F" />
          <circle cx="24" cy="39" r="2.2" fill="#E8BFC5" />
          <circle cx="40" cy="39" r="2.2" fill="#E8BFC5" />
          <path d="M30 39 Q32 41 34 39" fill="none" stroke="#A6533B" strokeWidth="1.4" strokeLinecap="round" />
        </svg>
      );

    case 'star':
      return (
        <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
          <path
            d="M24 6 L28.6 17.6 L41 18.6 L31.5 26.8 L34.4 39 L24 32.4 L13.6 39 L16.5 26.8 L7 18.6 L19.4 17.6 Z"
            fill="#C4A574"
            fillOpacity="0.45"
            stroke="#A6533B"
            strokeWidth="1.5"
            strokeLinejoin="round"
          />
        </svg>
      );

    case 'heart':
      return (
        <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
          <path
            d="M24 39 C13 31 8 23 11 16 C13.5 10.5 20.5 10.5 24 15.5 C27.5 10.5 34.5 10.5 37 16 C40 23 35 31 24 39 Z"
            fill="#E8BFC5"
            stroke="#743D4A"
            strokeWidth="1.5"
          />
        </svg>
      );

    case 'cloud':
      return (
        <svg viewBox="0 0 64 40" className={className} aria-hidden="true">
          <path
            d="M16 30 H48 C53 30 56 26 55 21 C54 16 49 14 45 15 C43 9 37 6 31 8 C26 9 23 13 22 17 C16 16 11 20 11 25 C11 28 13 30 16 30 Z"
            fill="#FBF6EE"
            stroke="#38271F"
            strokeOpacity="0.35"
            strokeWidth="1.4"
          />
        </svg>
      );

    case 'paperclip':
      return (
        <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
          <path
            d="M17 31 L17 15 C17 10 25 10 25 15 L25 33 C25 36.5 20 36.5 20 33 L20 18"
            fill="none"
            stroke="#38271F"
            strokeOpacity="0.65"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      );

    case 'ribbon':
      return (
        <svg viewBox="0 0 64 36" className={className} aria-hidden="true">
          <path
            d="M6 12 H56 L50 18 L56 24 H6 L12 18 Z"
            fill="#E8BFC5"
            fillOpacity="0.65"
            stroke="#743D4A"
            strokeOpacity="0.55"
            strokeWidth="1.3"
          />
        </svg>
      );

    case 'stamp':
    default:
      return (
        <div
          aria-hidden="true"
          className="postage-stamp px-2 py-0.5 text-[8px] sm:text-[9px] font-semibold tracking-wider text-[#743D4A] uppercase select-none whitespace-nowrap"
        >
          {label || 'MEMORY'}
        </div>
      );
  }
}

const POSITION_CLASSES: Record<PageDecoration['position'], string> = {
  'top-left': 'top-2.5 left-2.5 sm:top-3.5 sm:left-3.5',
  'top-right': 'top-2.5 right-2.5 sm:top-3.5 sm:right-3.5',
  'bottom-left': 'bottom-7 left-2.5 sm:bottom-8 sm:left-3.5',
  'bottom-right': 'bottom-7 right-2.5 sm:bottom-8 sm:right-3.5',
  'mid-left': 'top-1/2 -translate-y-1/2 left-1.5 sm:left-2.5',
  'mid-right': 'top-1/2 -translate-y-1/2 right-1.5 sm:right-2.5',
};

export function PageDecorationsLayer({ decorations }: { decorations: PageDecoration[] }) {
  return (
    <>
      {decorations.map((dec, idx) => {
        const animClass =
          dec.animate === 'float'
            ? 'story-animate-float'
            : dec.animate === 'sway'
              ? 'story-animate-sway'
              : '';
        return (
          <div
            key={`${dec.kind}-${dec.position}-${idx}`}
            aria-hidden="true"
            style={dec.rotation ? { transform: `rotate(${dec.rotation}deg)` } : undefined}
            className={`pointer-events-none absolute z-10 opacity-85 ${POSITION_CLASSES[dec.position]}`}
          >
            <div className={animClass}>
              <DecorationSVG
                kind={dec.kind}
                label={dec.label}
                className="w-6 h-6 sm:w-8 sm:h-8 md:w-9 md:h-9"
              />
            </div>
          </div>
        );
      })}
    </>
  );
}
