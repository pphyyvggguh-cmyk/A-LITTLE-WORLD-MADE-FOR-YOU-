export type OktafPose =
  | 'standing'
  | 'walking'
  | 'running'
  | 'jumping'
  | 'sitting'
  | 'sleeping'
  | 'waving'
  | 'pointing'
  | 'gift'
  | 'cake'
  | 'peeking'
  | 'cheering'
  | 'birthday_cake'
  | 'globe'
  | 'heart'
  | 'curious'
  | 'celebrating'
  | 'relaxing';

export type OktafExpression =
  | 'normal'
  | 'happy'
  | 'laughing'
  | 'surprised'
  | 'pouty'
  | 'shy'
  | 'sleepy'
  | 'wink';

export interface OktafDialogueEntry {
  pose: OktafPose;
  expression: OktafExpression;
  message: string;
}

export const OKTAF_POSE_PATHS: Record<OktafPose, string> = {
  standing: '/assets/characters/poses/standing.png',
  walking: '/assets/characters/poses/walking.png',
  running: '/assets/characters/poses/running.png',
  jumping: '/assets/characters/poses/jumping.png',
  sitting: '/assets/characters/poses/sitting.png',
  sleeping: '/assets/characters/poses/sleeping.png',
  waving: '/assets/characters/poses/waving.png',
  pointing: '/assets/characters/poses/pointing.png',
  gift: '/assets/characters/poses/gift.png',
  cake: '/assets/characters/poses/cake.png',
  peeking: '/assets/characters/poses/peeking.png',
  cheering: '/assets/characters/poses/cheering.png',
  birthday_cake: '/assets/characters/poses/birthday_cake.png',
  globe: '/assets/characters/poses/globe.png',
  heart: '/assets/characters/poses/heart.png',
  curious: '/assets/characters/poses/curious.png',
  celebrating: '/assets/characters/poses/celebrating.png',
  relaxing: '/assets/characters/poses/relaxing.png',
};

export const OKTAF_EXPRESSION_PATHS: Record<OktafExpression, string> = {
  normal: '/assets/characters/expressions/normal.png',
  happy: '/assets/characters/expressions/happy.png',
  laughing: '/assets/characters/expressions/laughing.png',
  surprised: '/assets/characters/expressions/surprised.png',
  pouty: '/assets/characters/expressions/pouty.png',
  shy: '/assets/characters/expressions/shy.png',
  sleepy: '/assets/characters/expressions/sleepy.png',
  wink: '/assets/characters/expressions/wink.png',
};

export const SECTION_DIALOGUES: Record<string, OktafDialogueEntry> = {
  welcome: {
    pose: 'waving',
    expression: 'happy',
    message: 'Haii Wulan! Akhirnya kamu datang juga! Selamat ulang tahun ya ♡',
  },
  hub: {
    pose: 'pointing',
    expression: 'happy',
    message: 'Selamat datang di dunia kecil kita! Mau mulai dari mana dulu nih?',
  },
  story: {
    pose: 'heart',
    expression: 'happy',
    message: 'Semua kenangan ini punya cerita masing-masing. Yuk, kita lihat satu-satu.',
  },
  world: {
    pose: 'globe',
    expression: 'wink',
    message: 'Ini tempat-tempat yang pengen kita kunjungi suatu hari nanti!',
  },
  letters: {
    pose: 'gift',
    expression: 'shy',
    message: 'Ada beberapa surat kecil yang disiapkan khusus buat kamu...',
  },
  video: {
    pose: 'birthday_cake',
    expression: 'happy',
    message:
      'Sebenarnya ada sesuatu yang pengen disampaikan langsung sama Oktaf. Aku udah nyiapin videonya buat kamu.',
  },
  videoEnded: {
    pose: 'heart',
    expression: 'wink',
    message: 'Gimana videonya, Wulan? Mau putar ulang atau balik ke beranda dulu? ♡',
  },
  voices: {
    pose: 'cheering',
    expression: 'happy',
    message: 'Dengar suara hangat dari sahabat-sahabat yang ikut merayakan harimu di taman bunga ini ♡',
  },
  wishlist: {
    pose: 'heart',
    expression: 'happy',
    message: 'Ini lembaran rahasia impian dan rencana masa depan kita berdua ♡',
  },
  reward: {
    pose: 'celebrating',
    expression: 'laughing',
    message: 'YEAY! Semua bunganya berhasil ditemukan! Selamat membaca halaman rahasia ini ♡',
  },
};

export const HUB_CARD_REACTIONS: Record<string, OktafDialogueEntry> = {
  story: {
    pose: 'heart',
    expression: 'happy',
    message: 'Yuk buka lembar-lembar Polaroid kenangan kita!',
  },
  world: {
    pose: 'globe',
    expression: 'wink',
    message: 'Siap keliling dunia bareng pesawat kecil kita?',
  },
  letters: {
    pose: 'gift',
    expression: 'shy',
    message: 'Pelan-pelan ya bukanya, setiap amplop punya cerita sendiri.',
  },
  video: {
    pose: 'birthday_cake',
    expression: 'happy',
    message: 'Duduk manis dulu, ada pesan spesial yang nungguin kamu!',
  },
  voices: {
    pose: 'cheering',
    expression: 'happy',
    message: 'Ada suara-suara sahabat tercinta yang mekar di Taman Suara!',
  },
  wishlist: {
    pose: 'heart',
    expression: 'wink',
    message: 'Catat mimpi, rencana liburan, dan kenangan indah kita berdua di sini!',
  },
};

export const CURIOUS_TAP_REACTIONS: OktafDialogueEntry[] = [
  {
    pose: 'curious',
    expression: 'surprised',
    message: 'Eh? Kenapa mencet-mencet aku nih? Ada rahasia kalau diketuk dua kali lho...',
  },
  {
    pose: 'peeking',
    expression: 'wink',
    message: 'Psst! Coba ketuk aku dua kali dengan cepat kalau mau lihat misi rahasia ♡',
  },
  {
    pose: 'cheering',
    expression: 'laughing',
    message: 'Hehe, aku di sini selalu nemenin kamu kok, Wulan!',
  },
  {
    pose: 'sitting',
    expression: 'shy',
    message: 'Kalau aku nutupin layar, tinggal geser atau sembunyikan aku sebentar ya~',
  },
];

export const QUEST_DIALOGUES = {
  discovered: {
    pose: 'peeking',
    expression: 'surprised',
    message: 'Eh? Kayaknya ada sesuatu yang tersembunyi di dunia ini...',
  } satisfies OktafDialogueEntry,
  flowerCollected: (count: number, total: number, flowerName: string): OktafDialogueEntry => ({
    pose: count >= total ? 'celebrating' : 'jumping',
    expression: count >= total ? 'laughing' : 'happy',
    message:
      count >= total
        ? 'YEAY! Semua bunganya berhasil ditemukan! ♡'
        : `Wahh, kamu nemu ${flowerName}! (${count}/${total}) Masih ada bunga lainnya yang harus dicari!`,
  }),
};
