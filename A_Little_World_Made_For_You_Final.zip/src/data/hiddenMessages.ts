export interface HiddenEnvelopeMessage {
  id: string;
  label: string;
  hint: string;
  greeting: string;
  message: string;
  signature: string;
  sealColor: string;
  stampText: string;
}

/**
 * Centralized editable messages for small hidden paper envelopes tucked inside Our Story pages.
 * Edit any greeting, message, or signature here without touching UI components.
 */
export const HIDDEN_MESSAGES: Record<string, HiddenEnvelopeMessage> = {
  'env-page-06': {
    id: 'env-page-06',
    label: 'Catatan Kecil · Hal. 06',
    hint: 'Ketuk amplop kecil',
    greeting: 'Untuk Wulan,',
    message:
      'Kadang hal-hal paling manis justru tersimpan di momen kecil yang hampir terlewat. Terima kasih sudah membuat hari-hari biasa terasa selalu layak diingat. (Kamu bisa mengganti catatan rahasia ini kapan saja di src/data/hiddenMessages.ts)',
    signature: 'Dengan hangat ♡',
    sealColor: '#A6533B',
    stampText: 'SECRET NOTE',
  },
  'env-page-08': {
    id: 'env-page-08',
    label: 'Tiket Rahasia · Hal. 08',
    hint: 'Buka lipatan surat',
    greeting: 'Hai, partner jalan-jalan,',
    message:
      'Ke mana pun langkah berikutnya membawa kita nanti, semoga selalu ada tawa kecil di perjalanan, lagu yang pas di telinga, dan cerita baru untuk dibawa pulang.',
    signature: 'Sampai perjalanan berikutnya ♡',
    sealColor: '#455342',
    stampText: 'FIRST CLASS',
  },
  'env-page-11': {
    id: 'env-page-11',
    label: 'Bisikan Botani · Hal. 11',
    hint: 'Ada surat terselip',
    greeting: 'Buat kamu yang selalu teliti,',
    message:
      'Semoga di sela hari-hari yang padat, kamu selalu ingat untuk berhenti sebentar, tarik napas pelan, dan sadar betapa berharganya dirimu.',
    signature: 'Dari penjaga halaman kecil ini ♡',
    sealColor: '#743D4A',
    stampText: 'PRESSED LEAF',
  },
  'env-page-14': {
    id: 'env-page-14',
    label: 'Doa Ulang Tahun · Hal. 14',
    hint: 'Buka pesan ulang tahun',
    greeting: 'Selamat ulang tahun, Wulan ♡',
    message:
      'Semoga tahun barumu dipenuhi langkah yang tenang, kesehatan yang terjaga, senyum yang tulus, serta keberanian untuk menyambut semua hal baik yang sedang menunggumu.',
    signature: 'Selalu mendoakan yang terbaik',
    sealColor: '#A6533B',
    stampText: '02 · APR · 26',
  },
  'env-page-16': {
    id: 'env-page-16',
    label: 'Refleksi Kecil · Hal. 16',
    hint: 'Baca catatan pribadi',
    greeting: 'Catatan untuk diingat nanti,',
    message:
      'Buku kenangan ini mungkin hanya memuat sebagian kecil dari cerita yang ada, karena bagian terbaiknya selalu terjadi saat kita benar-benar menjalani harinya bersama.',
    signature: 'Selalu hangat ♡',
    sealColor: '#C4A574',
    stampText: 'KEEPSAKE',
  },
  'env-page-17': {
    id: 'env-page-17',
    label: 'Pesan Penutup · Hal. 17',
    hint: 'Buka surat terakhir',
    greeting: 'Untuk bab-bab selanjutnya,',
    message:
      'Halaman 17 ini bukan akhir dari apa pun—justru pengingat bahwa masih ada sangat banyak lembar putih yang menanti untuk kita isi bersama.',
    signature: 'Our story is still being written ♡',
    sealColor: '#743D4A',
    stampText: 'TO BE CONTINUED',
  },
};
