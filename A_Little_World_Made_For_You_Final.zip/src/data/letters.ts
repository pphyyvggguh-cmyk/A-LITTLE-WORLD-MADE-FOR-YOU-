export interface BirthdayLetter {
  id: string;
  title: string;
  recipient: string;
  sender: string;
  dateLabel: string;
  stampText: string;
  sealColor: string;
  preview: string;
  paragraphs: string[];
  closing: string;
}

/**
 * Editable collection of personal Birthday Letters.
 * Update these messages directly without touching UI components.
 */
export const LETTERS_DATA: BirthdayLetter[] = [
  {
    id: 'letter-01',
    title: 'Untuk Hari Ulang Tahunmu',
    recipient: 'Wulan',
    sender: 'Dari aku, di dunia kecil ini',
    dateLabel: '02 April 2026',
    stampText: 'WULAN · 02.04',
    sealColor: '#A6533B',
    preview: 'Selamat ulang tahun ya, Wulan. Semoga halaman baru usiamu penuh hal-hal hangat...',
    paragraphs: [
      'Selamat ulang tahun ya, Wulan.',
      'Di hari yang spesial ini, semoga langkahmu selalu terasa ringan, hatimu selalu punya tempat yang tenang untuk pulang, dan senyummu tetap menjadi salah satu hal paling hangat yang pernah ada.',
      'Website kecil ini dibuat supaya kapan pun kamu lagi lelah atau lagi rindu cerita, kamu bisa mampir ke sini sebentar dan ingat bahwa ada seseorang yang selalu mendoakan yang terbaik buat kamu.',
      'Jangan lupa jaga kesehatan, makan yang teratur, dan tetap jadi diri kamu sendiri yang luar biasa ya.',
    ],
    closing: 'Dengan doa paling hangat, ♡',
  },
  {
    id: 'letter-02',
    title: 'Tentang Hal-Hal Kecil',
    recipient: 'Wulan',
    sender: 'Catatan Tengah Malam',
    dateLabel: 'Surat Kedua',
    stampText: 'CATATAN · 02',
    sealColor: '#743D4A',
    preview: 'Terima kasih sudah selalu sabar dan membawa warna di hari-hari yang biasa...',
    paragraphs: [
      'Kadang hal yang paling kita syukuri bukan sesuatu yang megah, melainkan obrolan ringan yang bikin lupa waktu, atau tawa kecil yang muncul di sela hari yang padat.',
      'Terima kasih ya sudah hadir dengan caramu yang lembut, perhatianmu yang tulus, dan ketenangan yang selalu kamu bawa.',
      'Bagian surat ini bisa kamu edit lagi kapan saja kalau ingin menambahkan pesan pribadi yang lebih panjang.',
    ],
    closing: 'Selalu bersyukur ada kamu,',
  },
  {
    id: 'letter-03',
    title: 'Mimpi & Perjalanan Kita',
    recipient: 'Wulan',
    sender: 'Pos Udara',
    dateLabel: 'Surat Ketiga',
    stampText: 'AIR MAIL · 20',
    sealColor: '#455342',
    preview: 'Dua puluh titik di bola dunia itu bukan cuma pin di peta, tapi harapan kecil...',
    paragraphs: [
      'Kalau kamu sudah mampir ke bagian Our World, di sana ada dua puluh kota yang siap kita tandai bersama suatu hari nanti.',
      'Semoga suatu saat nanti, satu per satu tempat di peta kecil itu benar-benar bisa kita pijak bersama—bukan cuma sebagai gambar Polaroid di layar, tapi sebagai foto sungguhan di album kita.',
      'Pelan-pelan saja, yang penting kita melangkah dengan baik dan terus saling mendukung.',
    ],
    closing: 'Sampai ketemu di perjalanan berikutnya,',
  },
  {
    id: 'letter-04',
    title: 'Kapan Pun Kamu Lelah',
    recipient: 'Wulan',
    sender: 'Simpanan Hati',
    dateLabel: 'Surat Keempat',
    stampText: 'KEEP · SAFE',
    sealColor: '#C4A574',
    preview: 'Kalau suatu hari rasanya berat, buka lagi surat ini dan tarik napas pelan-pelan ya...',
    paragraphs: [
      'Tidak semua hari berjalan mulus, dan tidak apa-apa kalau sesekali kamu merasa capek atau butuh jeda sebentar dari ramainya dunia.',
      'Ingatlah bahwa kamu tidak harus selalu sempurna untuk tetap berharga. Kamu sudah berusaha sejauh ini dengan sangat hebat.',
      'Tarik napas pelan-pelan, istirahat secukupnya, dan ingat: dunia kecil ini selalu ada buat kamu kunjungi lagi kapan pun kamu mau.',
    ],
    closing: 'Peluk hangat dari jauh, ♡',
  },
];
