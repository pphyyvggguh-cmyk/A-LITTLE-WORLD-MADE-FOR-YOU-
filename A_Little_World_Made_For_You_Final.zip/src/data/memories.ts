export type PolaroidSize = 'sm' | 'md' | 'lg';
export type BookPolaroidSize = 'xs' | 'sm' | 'md' | 'lg';
export type TapeVariant = 'pink' | 'gold' | 'sage';
export type PolaroidAspect = 'portrait' | 'landscape' | 'square';

export type PageLayoutType =
  | 'intro-polaroid-note'
  | 'floral-spotlight'
  | 'asymmetric-mini-cluster'
  | 'layered-collage-captions'
  | 'large-pressed-botanical'
  | 'stickers-and-secret-note'
  | 'travel-stamps-map'
  | 'ticket-stubs-arrangement'
  | 'portrait-gallery-frame'
  | 'landscape-storytelling'
  | 'woodland-botanical-sketch'
  | 'multi-photo-margin-notes'
  | 'central-heirloom-frame'
  | 'journal-letter-composition'
  | 'memory-constellation-grid'
  | 'reflective-keepsake-quote'
  | 'final-chapter-finale';

export type DecorationKind =
  | 'daisy'
  | 'rose'
  | 'wildflower'
  | 'leaf'
  | 'branch'
  | 'butterfly'
  | 'bird'
  | 'bee'
  | 'cat'
  | 'rabbit'
  | 'star'
  | 'heart'
  | 'cloud'
  | 'stamp'
  | 'paperclip'
  | 'ribbon';

export interface PageDecoration {
  kind: DecorationKind;
  position: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'mid-left' | 'mid-right';
  rotation?: number;
  animate?: 'float' | 'sway';
  label?: string;
}

export interface BookPolaroidItem {
  id: string;
  image: string;
  title: string;
  date: string;
  location: string;
  caption: string;
  story: string;
  aspect: PolaroidAspect;
  size: BookPolaroidSize;
  rotation: number;
  tape?: TapeVariant | null;
  pinColor?: string;
  sticker?: 'heart' | 'star' | 'flower' | 'clip';
  stamp?: string;
}

export interface MemoryBookPage {
  id: string;
  pageNumber: number; // Strictly 1..17
  spreadNumber: number; // 1..9
  spreadTheme: string;
  title: string;
  subtitle?: string;
  handwrittenNote?: string;
  bodyCopy?: string;
  layoutType: PageLayoutType;
  paperTint?: 'ivory' | 'warm-linen' | 'blush-tint' | 'sage-tint';
  polaroids: BookPolaroidItem[];
  decorations: PageDecoration[];
  envelopeId?: string;
  extraTags?: string[];
}

/**
 * Editable 17-Page Memory Book dataset across 9 two-page spreads.
 * Replace image paths inside `public/assets/photos/memories/` and customize titles, dates,
 * captions, or longer stories without altering UI components.
 */
export const MEMORY_BOOK_PAGES: MemoryBookPage[] = [
  // SPREAD 1 — THE BEGINNING
  {
    id: 'page-01',
    pageNumber: 1,
    spreadNumber: 1,
    spreadTheme: 'Spread 1 · The Beginning',
    title: 'Halaman Pertama',
    subtitle: 'Bab 01 · Titik Awal',
    handwrittenNote: 'Untuk Wulan—di mana semua cerita hangat ini dimulai ♡',
    bodyCopy:
      'Setiap buku kenangan selalu dimulai dari satu momen sederhana yang ingin terus diingat.',
    layoutType: 'intro-polaroid-note',
    paperTint: 'ivory',
    polaroids: [
      {
        id: 'pol-01',
        image: '/assets/photos/memories/memory-01.svg',
        title: 'Halaman Pertama',
        date: 'Bab 01 · Awal Cerita',
        location: 'Sudut Favorit',
        caption: 'Meja sudut & obrolan sore',
        story:
          'Setiap cerita hangat selalu punya satu titik awal yang sederhana. Kamu dapat mengganti foto dan cerita ini dengan momen pertama yang paling berkesan bagi kalian.',
        aspect: 'landscape',
        size: 'lg',
        rotation: -2.5,
        tape: 'pink',
        stamp: 'CHAPTER 01',
      },
    ],
    decorations: [
      { kind: 'rose', position: 'top-right', rotation: 10, animate: 'sway' },
      { kind: 'heart', position: 'bottom-left', rotation: -8 },
      { kind: 'butterfly', position: 'mid-right', animate: 'float' },
    ],
  },
  {
    id: 'page-02',
    pageNumber: 2,
    spreadNumber: 1,
    spreadTheme: 'Spread 1 · The Beginning',
    title: 'Langkah Pertama',
    subtitle: 'Bab 02 · Percakapan Awal',
    handwrittenNote: 'Langkah pelan tanpa perlu terburu-buru',
    bodyCopy:
      'Dikelilingi kelopak bunga kecil, halaman ini menyimpan hangatnya awal mula saling mengenal.',
    layoutType: 'floral-spotlight',
    paperTint: 'warm-linen',
    polaroids: [
      {
        id: 'pol-02',
        image: '/assets/photos/memories/memory-02.svg',
        title: 'Langkah Kecil Bersama',
        date: 'Bab 02 · Jalan Santai',
        location: 'Sepanjang Trotoar',
        caption: 'Berjalan tanpa terburu-buru',
        story:
          'Kadang hal paling berkesan bukan tentang ke mana tujuannya, melainkan tentang siapa yang berjalan di sampingmu sambil bercerita tentang hal-hal kecil.',
        aspect: 'portrait',
        size: 'md',
        rotation: 2.2,
        tape: 'gold',
        pinColor: '#455342',
        sticker: 'flower',
      },
    ],
    decorations: [
      { kind: 'branch', position: 'top-left', rotation: -6, animate: 'sway' },
      { kind: 'daisy', position: 'bottom-right', rotation: 14, animate: 'sway' },
      { kind: 'wildflower', position: 'bottom-left', rotation: -12 },
    ],
  },

  // SPREAD 2 — LITTLE MOMENTS
  {
    id: 'page-03',
    pageNumber: 3,
    spreadNumber: 2,
    spreadTheme: 'Spread 2 · Little Moments',
    title: 'Potongan Momen Kecil',
    subtitle: 'Bab 03 · Hal-Hal Sederhana',
    handwrittenNote: 'Tiga kenangan mungil yang selalu bikin senyum sendiri',
    layoutType: 'asymmetric-mini-cluster',
    paperTint: 'ivory',
    polaroids: [
      {
        id: 'pol-03a',
        image: '/assets/photos/memories/memory-03.svg',
        title: 'Warna Langit Senja',
        date: 'Sore Keemasan',
        location: 'Teras Senja',
        caption: 'Langit hangat menjelang malam',
        story:
          'Langit sore selalu punya cara sendiri untuk membuat waktu terasa lebih pelan. Ganti potret ini dengan foto senja favorit.',
        aspect: 'square',
        size: 'sm',
        rotation: -4.2,
        tape: 'pink',
      },
      {
        id: 'pol-03b',
        image: '/assets/photos/memories/memory-04.svg',
        title: 'Di Bawah Satu Payung',
        date: 'Musim Hujan',
        location: 'Halte Kecil',
        caption: 'Gerimis sore & tawa kecil',
        story:
          'Hujan yang turun tiba-tiba seringkali berubah menjadi alasan paling manis untuk meneduh sebentar dan tertawa bersama.',
        aspect: 'landscape',
        size: 'sm',
        rotation: 3.4,
        tape: 'sage',
      },
      {
        id: 'pol-03c',
        image: '/assets/photos/memories/memory-05.svg',
        title: 'Kelopak Tersimpan',
        date: 'Sela Buku',
        location: 'Halaman Jurnal',
        caption: 'Bunga kecil di halaman catatan',
        story:
          'Seperti bunga kering yang diselipkan di halaman buku harian, kenangan kecil tetap hangat setiap kali dibuka kembali.',
        aspect: 'square',
        size: 'xs',
        rotation: -2.1,
        pinColor: '#A6533B',
      },
    ],
    decorations: [
      { kind: 'bee', position: 'top-right', animate: 'float' },
      { kind: 'star', position: 'bottom-left', rotation: 12 },
    ],
  },
  {
    id: 'page-04',
    pageNumber: 4,
    spreadNumber: 2,
    spreadTheme: 'Spread 2 · Little Moments',
    title: 'Kolase Sore Hari',
    subtitle: 'Bab 04 · Catatan Pinggir',
    handwrittenNote: 'Tersusun rapi tidak harus selalu simetris',
    bodyCopy:
      'Dua potongan foto yang saling melengkapi dengan catatan kecil di tepian kertas.',
    layoutType: 'layered-collage-captions',
    paperTint: 'blush-tint',
    polaroids: [
      {
        id: 'pol-04a',
        image: '/assets/photos/memories/memory-06.svg',
        title: 'Lampu-Lampu Malam',
        date: 'Pijar Kota',
        location: 'Pusat Kota',
        caption: 'Cahaya hangat di ujung jalan',
        story:
          'Ketika lampu jalan mulai menyala satu per satu, setiap sudut kota terasa seperti panggung kecil yang tenang.',
        aspect: 'landscape',
        size: 'md',
        rotation: -2.8,
        tape: 'gold',
        sticker: 'clip',
      },
      {
        id: 'pol-04b',
        image: '/assets/photos/memories/memory-07.svg',
        title: 'Catatan Pagi',
        date: 'Awal Hari',
        location: 'Meja Tulis',
        caption: 'Sapaan singkat penyemangat hari',
        story:
          'Sapaan kecil di pagi hari selalu berhasil membuat hari yang panjang terasa jauh lebih ringan untuk dijalani.',
        aspect: 'portrait',
        size: 'sm',
        rotation: 4.1,
        tape: 'pink',
      },
    ],
    decorations: [
      { kind: 'paperclip', position: 'top-left', rotation: -12 },
      { kind: 'leaf', position: 'bottom-right', rotation: 18, animate: 'sway' },
    ],
  },

  // SPREAD 3 — SWEET MEMORIES
  {
    id: 'page-05',
    pageNumber: 5,
    spreadNumber: 3,
    spreadTheme: 'Spread 3 · Sweet Memories',
    title: 'Bunga yang Disimpan',
    subtitle: 'Bab 05 · Koleksi Botani',
    handwrittenNote: 'Dibiarkan tetap mekar di antara lembaran kertas',
    bodyCopy:
      'Satu bingkai foto besar didampingi bunga-bunga tekan agar momen manis ini terasa abadi.',
    layoutType: 'large-pressed-botanical',
    paperTint: 'sage-tint',
    polaroids: [
      {
        id: 'pol-05',
        image: '/assets/photos/memories/memory-05.svg',
        title: 'Kenangan yang Mekar',
        date: 'Bab 05 · Koleksi Manis',
        location: 'Taman Kenangan',
        caption: 'Bunga kering & cerita hangat',
        story:
          'Ada momen-momen tertentu yang ingin disimpan rapat seperti bunga tekan di antara lembaran kertas linen.',
        aspect: 'landscape',
        size: 'lg',
        rotation: 1.4,
        tape: 'sage',
        sticker: 'flower',
      },
    ],
    decorations: [
      { kind: 'daisy', position: 'top-left', rotation: -10, animate: 'sway' },
      { kind: 'rose', position: 'bottom-right', rotation: 8, animate: 'sway' },
      { kind: 'wildflower', position: 'bottom-left', rotation: 6 },
    ],
  },
  {
    id: 'page-06',
    pageNumber: 6,
    spreadNumber: 3,
    spreadTheme: 'Spread 3 · Sweet Memories',
    title: 'Catatan Rahasia & Stiker',
    subtitle: 'Bab 06 · Sudut Manis',
    handwrittenNote: 'Psst... ada amplop kecil terselip di halaman ini!',
    layoutType: 'stickers-and-secret-note',
    paperTint: 'ivory',
    envelopeId: 'env-page-06',
    polaroids: [
      {
        id: 'pol-06a',
        image: '/assets/photos/memories/memory-08.svg',
        title: 'Daftar Putar Kita',
        date: 'Nada Favorit',
        location: 'Earphone Sebelah',
        caption: 'Lagu yang diputar berulang',
        story:
          'Ada lagu-lagu tertentu yang langsung mengingatkan pada satu momen dan satu senyuman spesifik setiap kali nadanya terdengar.',
        aspect: 'square',
        size: 'sm',
        rotation: -3.2,
        tape: 'pink',
        sticker: 'heart',
      },
      {
        id: 'pol-06b',
        image: '/assets/photos/memories/memory-09.svg',
        title: 'Bintang & Cerita Panjang',
        date: 'Tengah Malam',
        location: 'Langit Malam',
        caption: 'Obrolan yang tak terasa waktunya',
        story:
          'Malam yang tenang selalu memberi ruang bagi mimpi-mimpi besar maupun cerita sederhana yang dibisikkan pelan.',
        aspect: 'square',
        size: 'sm',
        rotation: 2.8,
        tape: 'gold',
        sticker: 'star',
      },
    ],
    decorations: [
      { kind: 'heart', position: 'top-right', rotation: 10 },
      { kind: 'butterfly', position: 'mid-left', animate: 'float' },
    ],
  },

  // SPREAD 4 — OUR LITTLE WORLD
  {
    id: 'page-07',
    pageNumber: 7,
    spreadNumber: 4,
    spreadTheme: 'Spread 4 · Our Little World',
    title: 'Jurnal Perjalanan Kecil',
    subtitle: 'Bab 07 · Peta & Prangko',
    handwrittenNote: 'Ke mana pun langkah pergi, selalu bawa cerita pulang',
    bodyCopy:
      'Sentuhan prangko pos, koordinat kecil, dan catatan rute untuk mimpi-mimpi perjalanan.',
    layoutType: 'travel-stamps-map',
    paperTint: 'warm-linen',
    extraTags: ['POSTAGE PAID', 'LAT 6.9° S · LNG 107.6° E'],
    polaroids: [
      {
        id: 'pol-07',
        image: '/assets/photos/memories/memory-13.svg',
        title: 'Jendela Perjalanan',
        date: 'Bab 07 · Di Atas Rel',
        location: 'Dalam Perjalanan',
        caption: 'Pemandangan yang terus berganti',
        story:
          'Dari balik jendela kereta atau pesawat, setiap pemandangan baru selalu terasa lebih seru saat dibagi ceritanya bersamamu.',
        aspect: 'landscape',
        size: 'md',
        rotation: -1.8,
        tape: 'gold',
        stamp: 'AIR MAIL',
      },
    ],
    decorations: [
      { kind: 'stamp', position: 'top-right', rotation: 6, label: 'AIRMAIL · 2026' },
      { kind: 'cloud', position: 'top-left', animate: 'float' },
      { kind: 'bird', position: 'bottom-right', animate: 'float' },
    ],
  },
  {
    id: 'page-08',
    pageNumber: 8,
    spreadNumber: 4,
    spreadTheme: 'Spread 4 · Our Little World',
    title: 'Tiket & Karcis Kenangan',
    subtitle: 'Bab 08 · Koleksi Perjalanan',
    handwrittenNote: 'Setiap karcis kecil jadi bukti pernah tertawa di sana',
    layoutType: 'ticket-stubs-arrangement',
    paperTint: 'ivory',
    envelopeId: 'env-page-08',
    extraTags: ['BOARDING PASS · NO. 0204', 'SEAT · ALWAYS WITH YOU'],
    polaroids: [
      {
        id: 'pol-08a',
        image: '/assets/photos/memories/memory-10.svg',
        title: 'Bangku Taman Teduh',
        date: 'Akhir Pekan',
        location: 'Taman Kota',
        caption: 'Angin sepoi & daun hijau',
        story:
          'Duduk tenang di bawah pepohonan sambil memperhatikan sekitar—momen istirahat terbaik di tengah minggu yang sibuk.',
        aspect: 'landscape',
        size: 'sm',
        rotation: 2.4,
        tape: 'sage',
      },
      {
        id: 'pol-08b',
        image: '/assets/photos/memories/memory-06.svg',
        title: 'Sudut Kota Malam',
        date: 'Perjalanan Singkat',
        location: 'Ujung Jalan',
        caption: 'Lampu hangat setelah perjalanan',
        story:
          'Malam di kota baru selalu terasa akrab ketika ada teman berbagi cerita di sisi yang sama.',
        aspect: 'landscape',
        size: 'sm',
        rotation: -2.9,
        pinColor: '#743D4A',
      },
    ],
    decorations: [
      { kind: 'ribbon', position: 'bottom-left', rotation: -4 },
      { kind: 'star', position: 'top-left' },
    ],
  },

  // SPREAD 5 — THE DAYS WE KEEP
  {
    id: 'page-09',
    pageNumber: 9,
    spreadNumber: 5,
    spreadTheme: 'Spread 5 · The Days We Keep',
    title: 'Potret yang Disimpan',
    subtitle: 'Bab 09 · Bingkai Vertikal',
    handwrittenNote: 'Satu bingkai tegak untuk momen yang berdiri sendiri',
    bodyCopy:
      'Komposisi vertikal yang tenang, memberi ruang penuh bagi satu potret kesayangan.',
    layoutType: 'portrait-gallery-frame',
    paperTint: 'blush-tint',
    polaroids: [
      {
        id: 'pol-09',
        image: '/assets/photos/memories/memory-01.svg',
        title: 'Potret Favorit',
        date: 'Bab 09 · Hari Tenang',
        location: 'Bingkai Khusus',
        caption: 'Senyum hangat yang tak terlupa',
        story:
          'Halaman ini dibuat dengan format potret agar foto vertikal favoritmu dapat tampil penuh tanpa terpotong.',
        aspect: 'portrait',
        size: 'lg',
        rotation: -1.2,
        tape: 'pink',
        pinColor: '#A6533B',
      },
    ],
    decorations: [
      { kind: 'leaf', position: 'top-left', rotation: -15, animate: 'sway' },
      { kind: 'heart', position: 'bottom-right', rotation: 8 },
    ],
  },
  {
    id: 'page-10',
    pageNumber: 10,
    spreadNumber: 5,
    spreadTheme: 'Spread 5 · The Days We Keep',
    title: 'Cerita di Balik Pemandangan',
    subtitle: 'Bab 10 · Garis Horison',
    handwrittenNote: 'Kadang selembar pemandangan luas cukup untuk menjelaskan rasa',
    bodyCopy:
      'Saat sore turun perlahan, kita tahu ada hari-hari yang memang pantas ditulis lebih panjang di catatan tangan.',
    layoutType: 'landscape-storytelling',
    paperTint: 'ivory',
    polaroids: [
      {
        id: 'pol-10',
        image: '/assets/photos/memories/memory-03.svg',
        title: 'Pemandangan Sore',
        date: 'Bab 10 · Horison Tenang',
        location: 'Ujung Sore',
        caption: 'Langit luas & cerita pelan',
        story:
          'Foto lanskap ini disiapkan untuk momen pemandangan luas—baik laut, perbukitan, maupun langit sore yang sama-sama kita pandangi.',
        aspect: 'landscape',
        size: 'lg',
        rotation: 1.5,
        tape: 'gold',
        stamp: 'WIDE VIEW',
      },
    ],
    decorations: [
      { kind: 'cloud', position: 'top-right', animate: 'float' },
      { kind: 'bird', position: 'top-left', animate: 'float' },
    ],
  },

  // SPREAD 6 — TINY DETAILS
  {
    id: 'page-11',
    pageNumber: 11,
    spreadNumber: 6,
    spreadTheme: 'Spread 6 · Tiny Details',
    title: 'Hal-Hal Mungil yang Lucu',
    subtitle: 'Bab 11 · Taman Sketsa',
    handwrittenNote: 'Ditemani si kecil berkuping panjang, lebah, dan kupu-kupu',
    bodyCopy:
      'Detail-detail kecil yang sering luput dari perhatian justru membuat dunia kecil ini terasa hidup.',
    layoutType: 'woodland-botanical-sketch',
    paperTint: 'sage-tint',
    envelopeId: 'env-page-11',
    polaroids: [
      {
        id: 'pol-11',
        image: '/assets/photos/memories/memory-10.svg',
        title: 'Siang di Taman',
        date: 'Bab 11 · Detail Kecil',
        location: 'Bangku Teduh',
        caption: 'Bunga liar & teman kecil',
        story:
          'Halaman ini memadukan ilustrasi botani dan hewan-hewan kecil yang hangat—seperti halaman buku cerita favorit.',
        aspect: 'square',
        size: 'md',
        rotation: -2.0,
        tape: 'sage',
        sticker: 'flower',
      },
    ],
    decorations: [
      { kind: 'rabbit', position: 'bottom-left', rotation: -3 },
      { kind: 'cat', position: 'bottom-right', rotation: 4 },
      { kind: 'butterfly', position: 'top-right', animate: 'float' },
      { kind: 'bee', position: 'top-left', animate: 'float' },
    ],
  },
  {
    id: 'page-12',
    pageNumber: 12,
    spreadNumber: 6,
    spreadTheme: 'Spread 6 · Tiny Details',
    title: 'Catatan Pinggir Halaman',
    subtitle: 'Bab 12 · Dua Potret Hangat',
    handwrittenNote: 'Sedikit tulisan tangan untuk setiap bingkai foto',
    layoutType: 'multi-photo-margin-notes',
    paperTint: 'warm-linen',
    polaroids: [
      {
        id: 'pol-12a',
        image: '/assets/photos/memories/memory-02.svg',
        title: 'Trotoar Favorit',
        date: 'Pagi Cerah',
        location: 'Sudut Jalan',
        caption: 'Langkah ringan di hari baik',
        story:
          'Setiap detail kecil di sepanjang perjalanan selalu punya cerita lucunya sendiri.',
        aspect: 'square',
        size: 'sm',
        rotation: 2.5,
        tape: 'pink',
      },
      {
        id: 'pol-12b',
        image: '/assets/photos/memories/memory-04.svg',
        title: 'Gerimis Tipis',
        date: 'Sore Teduh',
        location: 'Beranda',
        caption: 'Teh hangat & suara hujan',
        story:
          'Tidak perlu momen megah—cukup obrolan santai sambil menunggu hujan reda.',
        aspect: 'square',
        size: 'sm',
        rotation: -3.1,
        tape: 'gold',
      },
    ],
    decorations: [
      { kind: 'wildflower', position: 'top-right', animate: 'sway' },
      { kind: 'paperclip', position: 'mid-left', rotation: 8 },
    ],
  },

  // SPREAD 7 — MORE THAN MEMORIES
  {
    id: 'page-13',
    pageNumber: 13,
    spreadNumber: 7,
    spreadTheme: 'Spread 7 · More Than Memories',
    title: 'Momen Perayaan Hangat',
    subtitle: 'Bab 13 · Bingkai Utama',
    handwrittenNote: 'Bukan sekadar foto, melainkan rasa syukur yang dibingkai',
    bodyCopy:
      'Satu bingkai utama di tengah halaman sebagai tanda terima kasih untuk setiap kebahagiaan kecil.',
    layoutType: 'central-heirloom-frame',
    paperTint: 'ivory',
    polaroids: [
      {
        id: 'pol-13',
        image: '/assets/photos/memories/memory-11.svg',
        title: 'Kue & Harapan Kecil',
        date: 'Bab 13 · Perayaan',
        location: 'Ruang Hangat',
        caption: 'Lilin menyala & doa baik',
        story:
          'Setiap perayaan selalu terasa lebih hangat saat diiringi doa-doa tulus untuk kesehatan, kebahagiaan, dan ketenangan hatimu.',
        aspect: 'landscape',
        size: 'lg',
        rotation: 0.8,
        tape: 'gold',
        stamp: 'CELEBRATE',
      },
    ],
    decorations: [
      { kind: 'star', position: 'top-left', rotation: -10 },
      { kind: 'rose', position: 'top-right', rotation: 10, animate: 'sway' },
      { kind: 'heart', position: 'bottom-left' },
    ],
  },
  {
    id: 'page-14',
    pageNumber: 14,
    spreadNumber: 7,
    spreadTheme: 'Spread 7 · More Than Memories',
    title: 'Sepucuk Jurnal Pribadi',
    subtitle: 'Bab 14 · Surat & Potret',
    handwrittenNote: 'Untuk Wulan, di hari istimewamu',
    bodyCopy:
      'Di antara foto-foto kenangan, ada baris kata yang ditulis pelan khusus agar selalu bisa kamu baca ulang kapan saja.',
    layoutType: 'journal-letter-composition',
    paperTint: 'blush-tint',
    envelopeId: 'env-page-14',
    polaroids: [
      {
        id: 'pol-14',
        image: '/assets/photos/memories/memory-14.svg',
        title: 'Selalu Kamu',
        date: '02 April 2026',
        location: 'Dunia Kecil Kita',
        caption: 'Selamat ulang tahun, Wulan ♡',
        story:
          'Terima kasih sudah hadir dan membawa warna sehangat ini. Halaman jurnal ini menyimpan doa baik untuk seluruh hari-harimu ke depan.',
        aspect: 'portrait',
        size: 'sm',
        rotation: -2.6,
        tape: 'pink',
        sticker: 'heart',
      },
    ],
    decorations: [
      { kind: 'ribbon', position: 'top-left' },
      { kind: 'butterfly', position: 'bottom-right', animate: 'float' },
    ],
  },

  // SPREAD 8 — FOREVER GROWING
  {
    id: 'page-15',
    pageNumber: 15,
    spreadNumber: 8,
    spreadTheme: 'Spread 8 · Forever Growing',
    title: 'Yang Terus Bertumbuh',
    subtitle: 'Bab 15 · Rangkaian Kenangan',
    handwrittenNote: 'Semakin banyak hari dilalui, semakin kaya ceritanya',
    layoutType: 'memory-constellation-grid',
    paperTint: 'sage-tint',
    polaroids: [
      {
        id: 'pol-15a',
        image: '/assets/photos/memories/memory-15.svg',
        title: 'Musim yang Berganti',
        date: 'Bab 15 · Bertumbuh',
        location: 'Sepanjang Waktu',
        caption: 'Tumbuh pelan bersama waktu',
        story:
          'Setiap musim membawa pelajarannya sendiri, dan setiap foto di sini menjadi pengingat betapa jauh langkah yang sudah ditempuh.',
        aspect: 'landscape',
        size: 'sm',
        rotation: -2.2,
        tape: 'sage',
      },
      {
        id: 'pol-15b',
        image: '/assets/photos/memories/memory-12.svg',
        title: 'Rencana Masa Depan',
        date: 'Menuju Esok',
        location: 'Halaman Baru',
        caption: 'Untuk semua hari yang datang',
        story:
          'Masih ada begitu banyak ruang yang menunggu untuk diisi dengan tawa baru dan perjalanan yang lebih indah.',
        aspect: 'square',
        size: 'sm',
        rotation: 3.1,
        tape: 'gold',
        sticker: 'star',
      },
    ],
    decorations: [
      { kind: 'branch', position: 'top-right', animate: 'sway' },
      { kind: 'daisy', position: 'bottom-left', animate: 'sway' },
    ],
  },
  {
    id: 'page-16',
    pageNumber: 16,
    spreadNumber: 8,
    spreadTheme: 'Spread 8 · Forever Growing',
    title: 'Ruang Tenang & Refleksi',
    subtitle: 'Bab 16 · Pesan Hati',
    handwrittenNote: 'Terima kasih sudah menjadi bagian paling hangat dari cerita ini',
    bodyCopy:
      'Bukan hanya tentang seberapa banyak foto yang terkumpul, tetapi tentang betapa nyamannya pulang pada cerita yang sama.',
    layoutType: 'reflective-keepsake-quote',
    paperTint: 'ivory',
    envelopeId: 'env-page-16',
    polaroids: [
      {
        id: 'pol-16',
        image: '/assets/photos/memories/memory-16.svg',
        title: 'Ruang Tenang',
        date: 'Bab 16 · Refleksi',
        location: 'Sudut Hati',
        caption: 'Nyaman tanpa perlu banyak kata',
        story:
          'Kadang kedekatan terbaik terasa saat keheningan pun terasa hangat dan tidak pernah terasa canggung.',
        aspect: 'square',
        size: 'md',
        rotation: 1.8,
        tape: 'pink',
        pinColor: '#743D4A',
      },
    ],
    decorations: [
      { kind: 'cat', position: 'bottom-left', rotation: -2 },
      { kind: 'rose', position: 'top-left', animate: 'sway' },
    ],
  },

  // SPREAD 9 — TO BE CONTINUED (Page 17 + complementary decorative closing side)
  {
    id: 'page-17',
    pageNumber: 17,
    spreadNumber: 9,
    spreadTheme: 'Spread 9 · To Be Continued',
    title: 'Lembar Ketujuh Belas',
    subtitle: 'Bab 17 · Sampai Hari Berikutnya',
    handwrittenNote: 'Semua halaman ini hanyalah pembuka untuk cerita-cerita berikutnya ♡',
    bodyCopy:
      'Terima kasih sudah membaca setiap lembar Memory Book ini. Selamat ulang tahun, Wulan—semoga kebahagiaan selalu menyertaimu.',
    layoutType: 'final-chapter-finale',
    paperTint: 'warm-linen',
    envelopeId: 'env-page-17',
    polaroids: [
      {
        id: 'pol-17',
        image: '/assets/photos/memories/memory-17.svg',
        title: 'Lembar Selanjutnya',
        date: '02 April 2026 · ∞',
        location: 'Masa Depan Kita',
        caption: 'Untuk cerita yang terus berlanjut',
        story:
          'Halaman ketujuh belas ini bukan penutup, melainkan penanda awal bagi ribuan kenangan manis lainnya yang menunggu untuk ditulis.',
        aspect: 'landscape',
        size: 'md',
        rotation: -1.5,
        tape: 'gold',
        stamp: 'TO BE CONTINUED',
      },
    ],
    decorations: [
      { kind: 'butterfly', position: 'top-right', animate: 'float' },
      { kind: 'star', position: 'bottom-left' },
      { kind: 'heart', position: 'top-left' },
    ],
  },
];
