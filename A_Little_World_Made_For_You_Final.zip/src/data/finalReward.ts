/**
 * Editable Final Reward journal page content (unlocked after collecting 7/7 flowers).
 */
export const FINAL_REWARD_DATA = {
  badge: 'Halaman Tersembunyi · 7/7 Bunga Terkumpul',
  title: 'Buket Kecil Untuk Wulan ♡',
  subtitle: 'Terima kasih sudah menjelajahi setiap sudut dunia kecil ini.',
  paragraphs: [
    'Ketujuh bunga yang barusan kamu temukan dirangkai jadi satu halaman rahasia di akhir jurnal ini.',
    'Setiap bunganya melambangkan doa-doa sederhana untukmu: semoga selalu diberi kesehatan, ketenangan hati, senyum yang tulus, dan keberanian untuk mengejar semua hal indah yang kamu impikan.',
    'Semoga dunia kecil ini selalu bisa jadi pengingat hangat bahwa setiap langkah dan ceritamu sangat berarti.',
  ],
  signature: 'Selamat ulang tahun sekali lagi, Wulan ♡',
  returnButtonLabel: 'Kembali ke Beranda',
};
