import type { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  serverTimestamp,
  setDoc,
  writeBatch,
} from 'firebase/firestore';
import { DESTINATIONS_DATA } from '../data/destinations';
import { LETTERS_DATA } from '../data/letters';
import { MEMORY_BOOK_PAGES } from '../data/memories';
import {
  CURIOUS_TAP_REACTIONS,
  HUB_CARD_REACTIONS,
  SECTION_DIALOGUES,
} from '../data/miniOktaf';
import { DEFAULT_VIDEO_CONFIG } from '../data/video';
import { DEFAULT_VINYL_CONFIG, DEFAULT_VINYL_PLAYLIST } from '../data/vinyl';
import { DEFAULT_ACCESS_CONFIG } from '../data/wishlist';
import type { SiteContentPayload } from './adminContent';
import { normalizeVoicesOrder, validateStoryBookPages } from './adminContent';
import { extractYouTubeVideoId, getYouTubeThumbnailUrl, normalizeVinylOrder } from './vinyl';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';

export interface MigrationReport {
  seededSections: string[];
  seededVinylTracks: number;
  bootstrappedAdmin: boolean;
  bootstrappedConfig: boolean;
}

/**
 * Idempotently seeds Firestore from bundled defaults ONLY when documents do not yet exist.
 * Never overwrites existing cloud content so Admin edits and uploaded assets remain intact.
 */
export async function ensureFirebaseBootstrapped(user: User): Promise<MigrationReport> {
  const report: MigrationReport = {
    seededSections: [],
    seededVinylTracks: 0,
    bootstrappedAdmin: false,
    bootstrappedConfig: false,
  };

  if (!user.emailVerified || (user.email || '').toLowerCase() !== DEFAULT_ACCESS_CONFIG.adminEmail) {
    return report;
  }

  // 1. Ensure /admins/{uid} exists
  const adminRef = doc(db, 'admins', user.uid);
  try {
    const adminSnap = await getDoc(adminRef);
    if (!adminSnap.exists()) {
      await setDoc(adminRef, {
        uid: user.uid,
        email: (user.email || DEFAULT_ACCESS_CONFIG.adminEmail).toLowerCase(),
        role: 'admin',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      report.bootstrappedAdmin = true;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `admins/${user.uid}`);
  }

  // 2. Ensure /config/access exists
  const configRef = doc(db, 'config', 'access');
  try {
    const configSnap = await getDoc(configRef);
    if (!configSnap.exists()) {
      await setDoc(configRef, {
        configId: 'access',
        adminEmail: DEFAULT_ACCESS_CONFIG.adminEmail,
        oktafEmail: DEFAULT_ACCESS_CONFIG.oktafEmail,
        wulanEmail: DEFAULT_ACCESS_CONFIG.wulanEmail,
        wishlistPrivacyMode: DEFAULT_ACCESS_CONFIG.wishlistPrivacyMode,
        updatedBy: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      report.bootstrappedConfig = true;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'config/access');
  }

  // 3. Seed missing /siteContent/{sectionId} documents idempotently
  const sectionSeeds: Array<{ sectionId: string; payload: Record<string, unknown> }> = [
    { sectionId: 'story', payload: { pages: MEMORY_BOOK_PAGES } },
    { sectionId: 'world', payload: { destinations: DESTINATIONS_DATA } },
    { sectionId: 'letters', payload: { letters: LETTERS_DATA } },
    { sectionId: 'video', payload: { videoConfig: DEFAULT_VIDEO_CONFIG } },
    {
      sectionId: 'miniOktaf',
      payload: {
        sectionDialogues: SECTION_DIALOGUES,
        hubCardReactions: HUB_CARD_REACTIONS,
        curiousTapReactions: CURIOUS_TAP_REACTIONS,
      },
    },
    { sectionId: 'vinyl', payload: { vinylConfig: DEFAULT_VINYL_CONFIG } },
  ];

  let vinylSectionJustSeeded = false;

  for (const item of sectionSeeds) {
    const ref = doc(db, 'siteContent', item.sectionId);
    try {
      const snap = await getDoc(ref);
      if (!snap.exists()) {
        await setDoc(ref, {
          sectionId: item.sectionId,
          payload: item.payload,
          updatedBy: user.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        report.seededSections.push(item.sectionId);
        if (item.sectionId === 'vinyl') vinylSectionJustSeeded = true;
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `siteContent/${item.sectionId}`);
    }
  }

  // 4. Seed default vinyl tracks ONLY if vinyl section was freshly created & collection is empty
  if (vinylSectionJustSeeded) {
    try {
      const existingTracks = await getDocs(collection(db, 'vinylPlaylist'));
      if (existingTracks.empty) {
        const batch = writeBatch(db);
        for (const track of normalizeVinylOrder(DEFAULT_VINYL_PLAYLIST)) {
          const trackRef = doc(db, 'vinylPlaylist', track.id);
          batch.set(trackRef, {
            id: track.id,
            youtubeUrl: track.youtubeUrl,
            youtubeVideoId: track.youtubeVideoId,
            title: track.title,
            artist: track.artist || '',
            thumbnailUrl: track.thumbnailUrl || getYouTubeThumbnailUrl(track.youtubeVideoId),
            order: track.order,
            isPublished: track.isPublished,
            ownerUid: user.uid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
          report.seededVinylTracks += 1;
        }
        await batch.commit();
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'vinylPlaylist');
    }
  }

  return report;
}

/**
 * Allows Admin to import/migrate a previously exported site-content.json backup into Firestore.
 */
export async function importJsonBackupToFirestore(
  user: User,
  rawJson: unknown
): Promise<{ importedSections: string[]; importedVoices: number }> {
  const parsed = rawJson as Partial<SiteContentPayload>;
  const importedSections: string[] = [];
  let importedVoices = 0;

  const saveSection = async (sectionId: string, payload: Record<string, unknown>) => {
    const ref = doc(db, 'siteContent', sectionId);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await setDoc(
        ref,
        {
          sectionId,
          payload,
          updatedBy: user.uid,
          createdAt: snap.data().createdAt || serverTimestamp(),
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
    } else {
      await setDoc(ref, {
        sectionId,
        payload,
        updatedBy: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
    importedSections.push(sectionId);
  };

  if (parsed.storyPages) {
    const check = validateStoryBookPages(parsed.storyPages);
    if (check.ok) {
      await saveSection('story', { pages: check.pages });
    }
  }

  if (Array.isArray(parsed.destinations) && parsed.destinations.length > 0) {
    await saveSection('world', { destinations: parsed.destinations });
  }

  if (Array.isArray(parsed.letters) && parsed.letters.length > 0) {
    await saveSection('letters', { letters: parsed.letters });
  }

  if (parsed.videoConfig && typeof parsed.videoConfig.title === 'string') {
    await saveSection('video', { videoConfig: parsed.videoConfig });
  }

  if (parsed.miniOktaf && parsed.miniOktaf.sectionDialogues) {
    await saveSection('miniOktaf', { ...parsed.miniOktaf });
  }

  if (Array.isArray(parsed.voices)) {
    const ordered = normalizeVoicesOrder(parsed.voices);
    const batch = writeBatch(db);
    for (const v of ordered) {
      if (!v.id || !v.name || !v.audioUrl || !v.permissionConfirmed) continue;
      const ref = doc(db, 'voices', v.id);
      const existing = await getDoc(ref);
      const data: Record<string, unknown> = {
        id: v.id,
        name: v.name.slice(0, 120),
        flowerType: v.flowerType,
        audioUrl: v.audioUrl,
        audioFileName: v.audioFileName || '',
        order: v.order,
        permissionConfirmed: true,
        updatedAt: serverTimestamp(),
      };
      if (v.photoUrl) data.photoUrl = v.photoUrl;
      if (v.message) data.message = v.message.slice(0, 1500);
      if (existing.exists()) {
        batch.update(ref, data);
      } else {
        batch.set(ref, {
          ...data,
          ownerUid: user.uid,
          createdAt: serverTimestamp(),
        });
      }
      importedVoices += 1;
    }
    if (importedVoices > 0) {
      await batch.commit();
    }
  }

  if (Array.isArray(parsed.vinylPlaylist) && parsed.vinylPlaylist.length > 0) {
    const ordered = normalizeVinylOrder(parsed.vinylPlaylist);
    const batch = writeBatch(db);
    for (const track of ordered) {
      const videoId = extractYouTubeVideoId(track.youtubeVideoId || track.youtubeUrl);
      if (!videoId || !track.id || !track.title) continue;
      const ref = doc(db, 'vinylPlaylist', track.id);
      const existing = await getDoc(ref);
      const payloadData = {
        id: track.id,
        youtubeUrl: track.youtubeUrl,
        youtubeVideoId: videoId,
        title: track.title.slice(0, 140),
        artist: (track.artist || '').slice(0, 120),
        thumbnailUrl: track.thumbnailUrl || getYouTubeThumbnailUrl(videoId),
        order: track.order,
        isPublished: track.isPublished !== false,
        updatedAt: serverTimestamp(),
      };
      if (existing.exists()) {
        batch.update(ref, payloadData);
      } else {
        batch.set(ref, {
          ...payloadData,
          ownerUid: user.uid,
          createdAt: serverTimestamp(),
        });
      }
    }
    await batch.commit();
  }

  return { importedSections, importedVoices };
}
