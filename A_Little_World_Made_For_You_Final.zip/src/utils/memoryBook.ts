export const TOTAL_MEMORY_PAGES = 17;
export const TOTAL_SPREADS = 9;
export const SESSION_SPREAD_STORAGE_KEY = 'wulan_memory_book_spread_v1';

export interface BookSpreadPair<T> {
  spreadIndex: number;
  spreadNumber: number;
  leftPage: T | null;
  rightPage: T | null;
}

/**
 * Group an exact 17-page book array into 9 two-page spreads.
 * Spreads 0..7 contain 2 facing pages each (pages 1..16).
 * Spread 8 contains page 17 on the left and a complementary unnumbered closing side (null) on the right.
 */
export function buildBookSpreads<T>(pages: readonly T[]): BookSpreadPair<T>[] {
  const spreads: BookSpreadPair<T>[] = [];
  for (let i = 0; i < TOTAL_SPREADS; i++) {
    const leftIdx = i * 2;
    const rightIdx = i * 2 + 1;
    spreads.push({
      spreadIndex: i,
      spreadNumber: i + 1,
      leftPage: pages[leftIdx] ?? null,
      rightPage: pages[rightIdx] ?? null,
    });
  }
  return spreads;
}

export function clampSpreadIndex(index: number, totalSpreads = TOTAL_SPREADS): number {
  if (!Number.isFinite(index)) return 0;
  return Math.max(0, Math.min(totalSpreads - 1, Math.floor(index)));
}

/**
 * Returns the readable page range indicator counting ONLY the 17 designed memory pages.
 */
export function getSpreadPageIndicator(
  spreadIndex: number,
  totalPages = TOTAL_MEMORY_PAGES
): string {
  const safeIdx = clampSpreadIndex(spreadIndex);
  const leftNum = safeIdx * 2 + 1;
  const rightNum = leftNum + 1;
  if (rightNum <= totalPages) {
    return `Halaman ${leftNum}–${rightNum} dari ${totalPages}`;
  }
  return `Halaman ${leftNum} dari ${totalPages}`;
}

/**
 * Computes reading progress percentage (based on highest memory page reached on the spread).
 */
export function getReadingProgressPercent(
  spreadIndex: number,
  totalPages = TOTAL_MEMORY_PAGES
): number {
  const safeIdx = clampSpreadIndex(spreadIndex);
  const highestPageReached = Math.min(totalPages, safeIdx * 2 + 2);
  return Math.round((highestPageReached / totalPages) * 100);
}

/**
 * Determines whether a horizontal drag/swipe gesture should flip the spread.
 * Ignores mostly-vertical gestures or short accidental micro-drags.
 */
export function detectSwipeDirection(
  dx: number,
  dy: number,
  thresholdPx = 48
): 'next' | 'prev' | null {
  if (Math.abs(dx) < thresholdPx) return null;
  if (Math.abs(dx) <= Math.abs(dy) * 1.25) return null;
  return dx < 0 ? 'next' : 'prev';
}

export function loadSessionSpreadIndex(): number {
  try {
    if (typeof window === 'undefined' || !window.sessionStorage) return 0;
    const raw = window.sessionStorage.getItem(SESSION_SPREAD_STORAGE_KEY);
    if (!raw) return 0;
    const parsed = Number.parseInt(raw, 10);
    return clampSpreadIndex(parsed);
  } catch {
    return 0;
  }
}

export function saveSessionSpreadIndex(spreadIndex: number): void {
  try {
    if (typeof window === 'undefined' || !window.sessionStorage) return;
    window.sessionStorage.setItem(
      SESSION_SPREAD_STORAGE_KEY,
      String(clampSpreadIndex(spreadIndex))
    );
  } catch {
    // Ignore storage errors safely
  }
}
