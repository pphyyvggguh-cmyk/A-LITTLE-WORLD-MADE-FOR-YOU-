import { useState } from 'react';
import { MemoryBook } from '../components/story/MemoryBook';
import { StoryMusic } from '../components/story/StoryMusic';

export function OurStory() {
  const [hasInteractedWithBook, setHasInteractedWithBook] = useState(false);

  return (
    <main className="book-desk-surface relative min-h-[calc(100dvh-3.5rem)] w-full pb-28 overflow-x-hidden">
      {/* Editorial Section Header & Ambient Music Control */}
      <div className="max-w-6xl mx-auto px-4 sm:px-8 pt-4 pb-2 flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <p className="text-xs tracking-widest uppercase text-[#743D4A] font-medium">
            01 · The Memory Book
          </p>
          <h1 className="mt-1 font-serif text-3xl sm:text-4xl font-semibold text-[#38271F] text-balance">
            Our Story
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-[#38271F]/75 max-w-xl">
            Buka bukunya untuk menjelajahi 17 halaman kenangan. Ketuk Polaroid atau amplop kecil di setiap lembar untuk membaca cerita lengkapnya.
          </p>
        </div>

        <div className="self-start sm:self-end">
          <StoryMusic shouldAutoStartAfterInteraction={hasInteractedWithBook} />
        </div>
      </div>

      {/* Centered Interactive Memory Book */}
      <div className="max-w-6xl mx-auto px-2 sm:px-6 pt-2">
        <MemoryBook onFirstBookInteraction={() => setHasInteractedWithBook(true)} />
      </div>
    </main>
  );
}
