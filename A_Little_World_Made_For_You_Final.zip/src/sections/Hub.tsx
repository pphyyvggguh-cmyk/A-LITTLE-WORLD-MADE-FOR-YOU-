import { motion } from 'motion/react';
import { BookHeart, CalendarHeart, Film, Flower2, Globe2, Lock, Mail, Sparkles } from 'lucide-react';
import { HiddenFlowerSpot } from '../components/Flower';
import { HUB_CARD_REACTIONS } from '../data/miniOktaf';
import { FLOWERS_DATA } from '../data/flowers';
import { useContentStore } from '../store/useContentStore';
import { AppSection, useStore } from '../store/useStore';
import { EASE_OUT_EXPO } from '../utils/animation';

interface HubCardItem {
  id: Exclude<AppSection, 'password' | 'welcome' | 'hub' | 'reward'>;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  accent: string;
  tapeClass: string;
  icon: typeof BookHeart;
  illustration: 'polaroids' | 'globe' | 'envelope' | 'cinema' | 'voices' | 'wishlist';
}

const HUB_CARDS: HubCardItem[] = [
  {
    id: 'story',
    number: '01',
    title: 'Our Story',
    subtitle: 'Scrapbook Kenangan',
    description: 'Kumpulan Polaroid, catatan kecil, dan benang merah momen-momen hangat kita.',
    accent: '#A6533B',
    tapeClass: 'washi-tape',
    icon: BookHeart,
    illustration: 'polaroids',
  },
  {
    id: 'world',
    number: '02',
    title: 'Our World',
    subtitle: 'Bola Dunia 3D & 20 Kota',
    description: 'Putar bumi kecil kita, jelajahi 20 destinasi impian, dan terbangkan pesawat kecilnya.',
    accent: '#455342',
    tapeClass: 'washi-tape-sage',
    icon: Globe2,
    illustration: 'globe',
  },
  {
    id: 'letters',
    number: '03',
    title: 'Birthday Letters',
    subtitle: 'Surat & Doa Pribadi',
    description: 'Amplop-amplop kecil berisi tulisan tangan dan doa hangat khusus untuk ulang tahunmu.',
    accent: '#743D4A',
    tapeClass: 'washi-tape-gold',
    icon: Mail,
    illustration: 'envelope',
  },
  {
    id: 'video',
    number: '04',
    title: 'Birthday Video',
    subtitle: 'Pesan Spesial',
    description: 'Putar pesan video spesial di dalam bingkai bioskop mini yang hangat.',
    accent: '#C4A574',
    tapeClass: 'washi-tape',
    icon: Film,
    illustration: 'cinema',
  },
  {
    id: 'voices',
    number: '05',
    title: 'Voices of Love ♡',
    subtitle: 'Taman Suara Sahabat',
    description: 'Koleksi pesan suara tulus dan doa hangat dari sahabat-sahabat yang menyayangimu.',
    accent: '#E8BFC5',
    tapeClass: 'washi-tape-gold',
    icon: Flower2,
    illustration: 'voices',
  },
  {
    id: 'wishlist',
    number: '06',
    title: 'Our Future Wishlist ♡',
    subtitle: 'Impian Masa Depan (Privat)',
    description: 'Ruang kolaborasi rahasia Oktaf & Wulan untuk menyimpan mimpi, rencana, dan foto pencapaian.',
    accent: '#455342',
    tapeClass: 'washi-tape-sage',
    icon: CalendarHeart,
    illustration: 'wishlist',
  },
];

function CardThumbnail({ type }: { type: HubCardItem['illustration'] }) {
  switch (type) {
    case 'polaroids':
      return (
        <svg viewBox="0 0 220 110" preserveAspectRatio="xMidYMid slice" className="w-full h-full" aria-hidden="true">
          <rect width="220" height="110" fill="#F2E6D6" />
          <g transform="translate(36 16) rotate(-7)">
            <rect width="62" height="76" rx="2" fill="#FBF8F2" stroke="#38271F" strokeOpacity="0.14" />
            <rect x="6" y="6" width="50" height="46" fill="#E8BFC5" opacity="0.7" />
            <circle cx="31" cy="29" r="10" fill="#A6533B" opacity="0.45" />
          </g>
          <g transform="translate(114 14) rotate(6)">
            <rect width="62" height="76" rx="2" fill="#FBF8F2" stroke="#38271F" strokeOpacity="0.14" />
            <rect x="6" y="6" width="50" height="46" fill="#C4A574" opacity="0.55" />
            <path d="M12 45 Q31 24 50 45" fill="none" stroke="#455342" strokeWidth="2" />
          </g>
          <path d="M68 20 Q110 40 144 18" fill="none" stroke="#A6533B" strokeWidth="1.5" strokeDasharray="3 3" />
          <circle cx="68" cy="20" r="3" fill="#A6533B" />
          <circle cx="144" cy="18" r="3" fill="#455342" />
        </svg>
      );
    case 'globe':
      return (
        <svg viewBox="0 0 220 110" preserveAspectRatio="xMidYMid slice" className="w-full h-full" aria-hidden="true">
          <rect width="220" height="110" fill="#182636" />
          <circle cx="42" cy="24" r="1.3" fill="#F4EBDD" opacity="0.7" />
          <circle cx="184" cy="28" r="1.5" fill="#C4A574" opacity="0.8" />
          <circle cx="164" cy="84" r="1.2" fill="#F4EBDD" opacity="0.55" />
          <circle cx="110" cy="56" r="36" fill="#2A4D69" stroke="#8FB3C9" strokeOpacity="0.4" strokeWidth="1.5" />
          <path d="M88 42 Q102 32 118 44 Q124 56 108 66 Q94 62 88 42 Z" fill="#6F8C67" opacity="0.85" />
          <path d="M125 54 Q138 50 142 66 Q130 78 122 68 Z" fill="#8BA882" opacity="0.8" />
          <path d="M72 48 Q110 14 152 48" fill="none" stroke="#E8BFC5" strokeWidth="1.5" strokeDasharray="4 3" />
          <polygon points="154,48 145,43 147,52" fill="#F4EBDD" />
        </svg>
      );
    case 'envelope':
      return (
        <svg viewBox="0 0 220 110" preserveAspectRatio="xMidYMid slice" className="w-full h-full" aria-hidden="true">
          <rect width="220" height="110" fill="#EFE2D0" />
          <rect x="46" y="22" width="128" height="70" rx="4" fill="#FBF6EE" stroke="#38271F" strokeOpacity="0.18" />
          <path d="M46 22 L110 64 L174 22" fill="none" stroke="#743D4A" strokeOpacity="0.45" strokeWidth="1.5" />
          <circle cx="110" cy="61" r="10" fill="#A6533B" />
          <path d="M110 66 C110 66 104 62 104 59 a3 3 0 0 1 6 -1 a3 3 0 0 1 6 1 C116 62 110 66 110 66 Z" fill="#F4EBDD" />
          <rect x="144" y="29" width="20" height="15" fill="none" stroke="#C4A574" strokeDasharray="2 2" />
        </svg>
      );
    case 'cinema':
      return (
        <svg viewBox="0 0 220 110" preserveAspectRatio="xMidYMid slice" className="w-full h-full" aria-hidden="true">
          <rect width="220" height="110" fill="#2A1F1A" />
          <rect x="38" y="16" width="144" height="78" rx="4" fill="#FBF6EE" />
          <rect x="46" y="24" width="128" height="62" rx="2" fill="#38271F" />
          <circle cx="110" cy="55" r="16" fill="#A6533B" opacity="0.9" />
          <polygon points="105,47 120,55 105,63" fill="#F4EBDD" />
        </svg>
      );
    case 'voices':
      return (
        <svg viewBox="0 0 220 110" preserveAspectRatio="xMidYMid slice" className="w-full h-full" aria-hidden="true">
          <rect width="220" height="110" fill="#F5E9EA" />
          <circle cx="70" cy="54" r="24" fill="#E8BFC5" opacity="0.6" />
          <circle cx="145" cy="56" r="22" fill="#C4A574" opacity="0.35" />
          <path d="M70 84 L70 54" stroke="#455342" strokeWidth="2.4" strokeLinecap="round" />
          <circle cx="70" cy="48" r="9" fill="#E8BFC5" stroke="#743D4A" strokeWidth="1.2" />
          <circle cx="70" cy="48" r="3.5" fill="#743D4A" />
          <path d="M145 84 L145 58" stroke="#455342" strokeWidth="2.4" strokeLinecap="round" />
          <circle cx="145" cy="51" r="8" fill="#D9A74A" stroke="#38271F" strokeWidth="1" />
          <circle cx="145" cy="51" r="3.2" fill="#38271F" />
          <path d="M96 55 Q102 42 108 55 Q114 68 120 55" fill="none" stroke="#A6533B" strokeWidth="2.2" strokeLinecap="round" />
        </svg>
      );
    case 'wishlist':
      return (
        <svg viewBox="0 0 220 110" preserveAspectRatio="xMidYMid slice" className="w-full h-full" aria-hidden="true">
          <rect width="220" height="110" fill="#EAE5D9" />
          <rect x="44" y="16" width="132" height="78" rx="6" fill="#FBF6EE" stroke="#455342" strokeOpacity="0.28" />
          <line x1="62" y1="36" x2="158" y2="36" stroke="#C4A574" strokeOpacity="0.4" strokeWidth="1.5" />
          <line x1="62" y1="54" x2="158" y2="54" stroke="#C4A574" strokeOpacity="0.4" strokeWidth="1.5" />
          <line x1="62" y1="72" x2="136" y2="72" stroke="#C4A574" strokeOpacity="0.4" strokeWidth="1.5" />
          <circle cx="66" cy="36" r="4" fill="#455342" />
          <circle cx="66" cy="54" r="4" fill="#A6533B" />
          <circle cx="66" cy="72" r="4" fill="#E8BFC5" stroke="#743D4A" strokeWidth="1" />
          <path d="M158 64 C158 64 150 58 150 54 a4 4 0 0 1 8 -1.5 a4 4 0 0 1 8 1.5 C166 58 158 64 158 64 Z" fill="#A6533B" />
        </svg>
      );
  }
}

export function Hub() {
  const navigateTo = useStore((s) => s.navigateTo);
  const setOktafDialogue = useStore((s) => s.setOktafDialogue);
  const collectedFlowers = useStore((s) => s.collectedFlowers);
  const questDiscovered = useStore((s) => s.questDiscovered);
  const setQuestModalOpen = useStore((s) => s.setQuestModalOpen);
  const hubCardReactions = useContentStore((s) => s.miniOktaf.hubCardReactions);

  const handleCardHover = (id: HubCardItem['id']) => {
    const reaction = hubCardReactions[id] ?? HUB_CARD_REACTIONS[id];
    if (reaction) {
      setOktafDialogue(reaction.pose, reaction.expression, reaction.message);
    }
  };

  return (
    <main className="paper-canvas relative min-h-[calc(100dvh-3.5rem)] w-full px-4 sm:px-8 pt-8 pb-28">
      <div className="max-w-5xl mx-auto">
        {/* Editorial Hub Header */}
        <motion.section
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: EASE_OUT_EXPO }}
          className="relative flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#38271F]/12"
        >
          <div>
            <p className="text-xs tracking-widest uppercase text-[#743D4A] font-medium">
              Beranda Jurnal · Untuk Wulan
            </p>
            <h1 className="mt-1.5 font-serif text-3xl sm:text-4xl font-semibold text-[#38271F] tracking-tight text-balance">
              A Little World Made For You ♡
            </h1>
            <p className="mt-2 text-sm sm:text-base text-[#38271F]/72 max-w-xl">
              Pilih salah satu bagian di bawah ini untuk mulai menjelajah. Setiap sudut menyimpan cerita kecilnya sendiri.
            </p>
          </div>

          {/* Flower #1 tucked naturally in the botanical header corner */}
          <div className="flex items-center gap-3 self-end sm:self-auto">
            <HiddenFlowerSpot flowerId="flower-sakura" />
          </div>
        </motion.section>

        {/* 4 Main Section Navigation Cards */}
        <section
          aria-label="Bagian utama dunia kecil"
          className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-7"
        >
          {HUB_CARDS.map((card, idx) => {
            const Icon = card.icon;
            return (
              <motion.button
                key={card.id}
                type="button"
                onClick={() => navigateTo(card.id)}
                onMouseEnter={() => handleCardHover(card.id)}
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.45, delay: idx * 0.08, ease: EASE_OUT_EXPO }}
                whileHover={{ y: -5, transition: { duration: 0.2, ease: EASE_OUT_EXPO } }}
                whileTap={{ scale: 0.985 }}
                className="group relative text-left bg-[#FBF6EE] border border-[#38271F]/14 rounded-xl p-4 sm:p-5 shadow-polaroid hover:shadow-polaroid-lifted transition-shadow cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#A6533B]"
              >
                {/* Decorative washi tape */}
                <span
                  aria-hidden="true"
                  className={`absolute -top-2.5 left-8 w-16 h-4 -rotate-2 ${card.tapeClass}`}
                />

                <div className="flex flex-col sm:flex-row gap-4 items-stretch">
                  <div className="w-full sm:w-44 h-32 sm:h-auto shrink-0 rounded-lg overflow-hidden border border-[#38271F]/12 bg-[#EAE0CF]">
                    <CardThumbnail type={card.illustration} />
                  </div>

                  <div className="flex-1 flex flex-col justify-between py-0.5">
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-medium text-[#743D4A] tabular-nums">
                          {card.number} · {card.subtitle}
                        </span>
                        <Icon
                          className="w-4 h-4 shrink-0 transition-transform group-hover:scale-110"
                          style={{ color: card.accent }}
                        />
                      </div>
                      <h2 className="mt-1.5 font-serif text-xl sm:text-2xl font-semibold text-[#38271F] group-hover:text-[#A6533B] transition-colors">
                        {card.title}
                      </h2>
                      <p className="mt-1.5 text-sm text-[#38271F]/72 leading-relaxed">
                        {card.description}
                      </p>
                    </div>

                    <div className="mt-4 pt-2.5 border-t border-[#38271F]/10 flex items-center justify-between text-xs font-medium text-[#38271F]">
                      <span>Buka Halaman</span>
                      <span className="transition-transform group-hover:translate-x-1">→</span>
                    </div>
                  </div>
                </div>
              </motion.button>
            );
          })}
        </section>

        {/* Subtle Secret Quest progress / gentle clue */}
        <section className="mt-9 pt-6 border-t border-[#38271F]/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          {questDiscovered ? (
            <div className="flex items-center gap-3">
              <Sparkles className="w-4 h-4 text-[#A6533B] shrink-0" />
              <p className="text-sm text-[#38271F]/80">
                Misi Rahasia terbuka:{' '}
                <strong className="font-semibold text-[#38271F] tabular-nums">
                  {collectedFlowers.length}/{FLOWERS_DATA.length} Bunga
                </strong>{' '}
                terkumpul.
              </p>
              <button
                type="button"
                onClick={() => setQuestModalOpen(true)}
                className="text-xs font-semibold text-[#A6533B] underline underline-offset-4 hover:text-[#743D4A] cursor-pointer whitespace-nowrap"
              >
                Lihat Daftar Misi
              </button>
            </div>
          ) : (
            <p className="font-hand text-lg text-[#38271F]/65">
              Bisikan jurnal: coba ketuk Mini Oktaf dua kali kalau kamu penasaran dengan rahasia kecil di dunia ini...
            </p>
          )}
          <a
            href="/admin"
            onClick={(e) => {
              e.preventDefault();
              window.history.pushState(null, '', '/admin');
              window.dispatchEvent(new PopStateEvent('popstate'));
            }}
            className="inline-flex items-center gap-1.5 text-[11px] font-medium text-[#38271F]/45 hover:text-[#743D4A] transition-colors shrink-0 min-h-[36px] px-2"
            aria-label="Masuk ke Control Room Admin"
          >
            <Lock className="w-3 h-3" />
            <span>Control Room</span>
          </a>
        </section>
      </div>
    </main>
  );
}
