import { useEffect, useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  CalendarHeart,
  CheckCircle2,
  Edit3,
  HeartHandshake,
  Lock,
  LogOut,
  Plus,
  Sparkles,
  Trash2,
  UserCheck,
} from 'lucide-react';
import { WishFormModal } from '../components/wishlist/WishFormModal';
import {
  WISHLIST_CATEGORY_META,
  WISHLIST_STATUS_META,
  WishlistCategory,
  WishlistEntry,
  WishlistStatus,
} from '../data/wishlist';
import { useFirebaseAuth } from '../lib/FirebaseProvider';
import {
  createWishlistEntry,
  deleteWishlistEntry,
  subscribeWishlistEntries,
  updateWishlistEntry,
} from '../utils/adminApi';
import { EASE_OUT_EXPO } from '../utils/animation';
import {
  canDeleteWishlistEntry,
  canEditWishlistEntry,
  filterWishlistEntries,
} from '../utils/wishlist';

export function FutureWishlist() {
  const {
    user,
    authReady,
    accessConfig,
    coupleRole,
    authError,
    signInWithGoogle,
    signOutUser,
  } = useFirebaseAuth();

  const [entries, setEntries] = useState<WishlistEntry[]>([]);
  const [loadingList, setLoadingList] = useState(false);
  const [syncError, setSyncError] = useState('');

  const [categoryFilter, setCategoryFilter] = useState<WishlistCategory | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<WishlistStatus | 'all'>('all');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<WishlistEntry | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!authReady || !user || !coupleRole || !user.email) {
      setEntries([]);
      return;
    }

    setLoadingList(true);
    setSyncError('');

    const unsub = subscribeWishlistEntries(
      user.email,
      coupleRole,
      (items) => {
        setEntries(items);
        setLoadingList(false);
      },
      (err) => {
        setSyncError(err.message);
        setLoadingList(false);
      }
    );

    return () => unsub();
  }, [authReady, user, coupleRole]);

  const visibleEntries = useMemo(
    () => filterWishlistEntries(entries, categoryFilter, statusFilter),
    [entries, categoryFilter, statusFilter]
  );

  const completedMemoriesCount = useMemo(
    () => entries.filter((item) => item.status === 'completed').length,
    [entries]
  );

  const handleOpenCreate = () => {
    setEditingEntry(null);
    setModalOpen(true);
  };

  const handleOpenEdit = (entry: WishlistEntry) => {
    setEditingEntry(entry);
    setModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    setSyncError('');
    try {
      await deleteWishlistEntry(id);
      setConfirmDeleteId(null);
    } catch (err) {
      setSyncError(err instanceof Error ? err.message : 'Gagal menghapus impian.');
    }
  };

  const handleQuickComplete = async (entry: WishlistEntry) => {
    if (!coupleRole) return;
    setSyncError('');
    try {
      await updateWishlistEntry(
        entry.id,
        entry.status,
        {
          title: entry.title,
          description: entry.description,
          category: entry.category,
          targetDate: entry.targetDate,
          status: 'completed',
          photos: entry.photos,
          completionStory: entry.completionStory,
          completedAt: new Date().toISOString(),
        },
        coupleRole
      );
    } catch (err) {
      setSyncError(err instanceof Error ? err.message : 'Gagal menandai selesai.');
    }
  };

  // Private Couple Gate when not authenticated or not authorized as Oktaf/Wulan
  if (!authReady) {
    return (
      <main className="paper-canvas min-h-[calc(100dvh-3.5rem)] flex items-center justify-center px-4 pb-24">
        <div className="rounded-2xl border border-[#38271F]/16 bg-[#FBF6EE] px-6 py-5 shadow-polaroid text-sm text-[#38271F]">
          Memeriksa ruang pribadi Our Future Wishlist ♡...
        </div>
      </main>
    );
  }

  if (!user || !coupleRole) {
    return (
      <main
        className="paper-canvas min-h-[calc(100dvh-3.5rem)] flex items-center justify-center px-4 py-10 pb-28"
        data-testid="wishlist-private-gate"
      >
        <motion.section
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: EASE_OUT_EXPO }}
          className="relative w-full max-w-md rounded-2xl border border-[#38271F]/16 bg-[#FBF6EE] p-6 sm:p-8 shadow-polaroid-lifted text-center space-y-5"
        >
          <span
            aria-hidden="true"
            className="washi-tape-gold absolute -top-3 left-1/2 -translate-x-1/2 w-24 h-5 -rotate-1"
          />

          <div className="w-12 h-12 mx-auto rounded-full bg-[#743D4A]/12 text-[#743D4A] flex items-center justify-center">
            <Lock className="w-5 h-5" />
          </div>

          <div>
            <p className="text-[11px] uppercase tracking-widest font-semibold text-[#743D4A]">
              Ruang Rahasia Berdua
            </p>
            <h1 className="mt-1 font-serif text-2xl sm:text-3xl font-semibold text-[#38271F]">
              Our Future Wishlist ♡
            </h1>
            <p className="mt-2.5 text-xs sm:text-sm text-[#38271F]/75 leading-relaxed">
              Halaman ini bersifat pribadi khusus untuk <strong>Oktaf</strong> dan{' '}
              <strong>Wulan</strong>. Pengunjung umum tidak dapat membaca maupun mengubah daftar impian kita.
            </p>
          </div>

          {user && !coupleRole && (
            <div
              role="alert"
              className="rounded-xl border border-[#A6533B]/30 bg-[#A6533B]/10 p-3.5 text-xs text-[#A6533B] text-left space-y-2"
            >
              <p className="font-semibold">
                Akun <span>{user.email}</span> belum terdaftar sebagai akun Oktaf atau Wulan.
              </p>
              <p className="text-[#38271F]/75">
                Jika kamu Wulan, minta Oktaf menambahkan email Google-mu di Control Room → Our Future Wishlist (Pengaturan Privasi).
              </p>
            </div>
          )}

          {authError && (
            <p
              role="alert"
              className="rounded-xl border border-[#A6533B]/30 bg-[#A6533B]/10 px-3.5 py-2.5 text-xs text-[#A6533B]"
            >
              {authError}
            </p>
          )}

          <div className="space-y-2.5">
            <button
              type="button"
              onClick={signInWithGoogle}
              className="w-full min-h-[48px] px-4 py-2.5 rounded-xl bg-[#38271F] text-[#F4EBDD] text-sm font-semibold hover:bg-[#4e382d] transition-colors inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <HeartHandshake className="w-4 h-4 text-[#E8BFC5]" />
              <span>{user ? 'Ganti Akun Google' : 'Masuk dengan Akun Google'}</span>
            </button>

            {user && (
              <button
                type="button"
                onClick={signOutUser}
                className="w-full min-h-[42px] px-4 py-2 rounded-xl border border-[#38271F]/20 text-xs font-semibold text-[#38271F] hover:bg-[#EAE0CF] cursor-pointer"
              >
                Keluar dari {user.email}
              </button>
            )}
          </div>
        </motion.section>
      </main>
    );
  }

  return (
    <main
      className="paper-canvas min-h-[calc(100dvh-3.5rem)] w-full px-4 sm:px-8 pt-8 pb-32 overflow-x-hidden"
      data-testid="future-wishlist-section"
    >
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <motion.header
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: EASE_OUT_EXPO }}
          className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#38271F]/12"
        >
          <div>
            <p className="text-xs tracking-widest uppercase text-[#743D4A] font-medium">
              06 · Ruang Pribadi Oktaf & Wulan
            </p>
            <h1 className="mt-1 font-serif text-3xl sm:text-4xl font-semibold text-[#38271F]">
              Our Future Wishlist ♡
            </h1>
            <p className="mt-1.5 text-sm sm:text-base text-[#38271F]/75 max-w-2xl">
              Tempat menyimpan mimpi pribadi, harapan masa depan, rencana perjalanan, dan kenangan yang sudah terwujud bersama.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#455342]/12 text-[#455342] text-xs font-semibold">
              <UserCheck className="w-3.5 h-3.5" />
              <span>Masuk sebagai {coupleRole === 'oktaf' ? 'Oktaf' : 'Wulan'}</span>
            </span>

            <button
              type="button"
              onClick={handleOpenCreate}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-[#38271F] text-[#F4EBDD] text-xs font-semibold inline-flex items-center gap-1.5 hover:bg-[#4e382d] cursor-pointer shadow-sm"
            >
              <Plus className="w-4 h-4 text-[#E8BFC5]" />
              <span>Tulis Impian Baru</span>
            </button>

            <button
              type="button"
              onClick={signOutUser}
              aria-label="Keluar dari akun Google"
              className="min-h-[44px] px-3 py-2 rounded-xl border border-[#38271F]/18 bg-[#FBF6EE] text-xs font-semibold text-[#38271F] inline-flex items-center gap-1 hover:bg-[#EAE0CF] cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5 text-[#A6533B]" />
              <span className="hidden sm:inline">Keluar</span>
            </button>
          </div>
        </motion.header>

        {/* Category & Status Filters */}
        <section className="rounded-2xl border border-[#38271F]/14 bg-[#FBF6EE] p-4 shadow-polaroid space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-1.5">
              {(
                [
                  ['all', `Semua (${entries.length})`],
                  ['our', WISHLIST_CATEGORY_META.our.label],
                  ['her', WISHLIST_CATEGORY_META.her.label],
                  ['your', WISHLIST_CATEGORY_META.your.label],
                ] as const
              ).map(([cat, label]) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategoryFilter(cat)}
                  className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                    categoryFilter === cat
                      ? 'bg-[#38271F] text-[#F4EBDD]'
                      : 'bg-[#F4EBDD] border border-[#38271F]/14 text-[#38271F] hover:bg-[#EAE0CF]'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() =>
                setStatusFilter((prev) => (prev === 'completed' ? 'all' : 'completed'))
              }
              className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer transition-colors ${
                statusFilter === 'completed'
                  ? 'bg-[#455342] text-[#F4EBDD]'
                  : 'bg-[#455342]/12 text-[#455342] hover:bg-[#455342]/20'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Kenangan Tercapai ({completedMemoriesCount})</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-[#38271F]/10">
            <span className="text-[11px] font-semibold text-[#743D4A] mr-1">Status:</span>
            {(
              [
                ['all', 'Semua Status'],
                ['dreaming', 'Dreaming'],
                ['planned', 'Planned'],
                ['in_progress', 'In Progress'],
                ['completed', 'Completed ♡'],
              ] as const
            ).map(([st, label]) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`min-h-[34px] px-3 rounded-lg text-[11px] font-semibold cursor-pointer transition-colors ${
                  statusFilter === st
                    ? 'bg-[#A6533B] text-[#F4EBDD]'
                    : 'bg-[#F4EBDD]/70 border border-[#38271F]/12 text-[#38271F]/80 hover:bg-[#EAE0CF]'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </section>

        {syncError && (
          <p
            role="alert"
            className="rounded-xl border border-[#A6533B]/30 bg-[#A6533B]/10 px-4 py-3 text-xs font-medium text-[#A6533B]"
          >
            {syncError}
          </p>
        )}

        {/* Wishlist Cards Grid */}
        {loadingList ? (
          <div className="rounded-2xl border border-[#38271F]/14 bg-[#FBF6EE] p-8 text-center text-sm text-[#38271F]/70">
            Menyinkronkan daftar impian kita dari Cloud Firestore...
          </div>
        ) : visibleEntries.length === 0 ? (
          <section className="rounded-2xl border border-dashed border-[#38271F]/22 bg-[#FBF6EE]/90 p-8 sm:p-10 text-center max-w-2xl mx-auto shadow-polaroid space-y-4">
            <CalendarHeart className="w-10 h-10 mx-auto text-[#A6533B]" />
            <h2 className="font-serif text-2xl font-semibold text-[#38271F]">
              Belum Ada Impian di Kategori Ini
            </h2>
            <p className="text-sm text-[#38271F]/72 leading-relaxed">
              Mulai tulis rencana kecil, destinasi impian, atau kejutan masa depan kita di sini. Setiap catatan langsung tersinkronisasi antara perangkat Oktaf dan Wulan ♡.
            </p>
            <button
              type="button"
              onClick={handleOpenCreate}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#38271F] text-[#F4EBDD] text-xs font-semibold inline-flex items-center gap-2 hover:bg-[#4e382d] cursor-pointer"
            >
              <Plus className="w-4 h-4 text-[#E8BFC5]" />
              <span>Tulis Impian Pertama</span>
            </button>
          </section>
        ) : (
          <section
            aria-label="Daftar kartu Our Future Wishlist"
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            {visibleEntries.map((entry) => {
              const catMeta = WISHLIST_CATEGORY_META[entry.category];
              const stMeta = WISHLIST_STATUS_META[entry.status];
              const canEdit = canEditWishlistEntry(entry, user.email, coupleRole);
              const canDelete = canDeleteWishlistEntry(entry, user.email, coupleRole);
              const isCompleted = entry.status === 'completed';

              return (
                <article
                  key={entry.id}
                  className={`relative rounded-2xl border bg-[#FBF6EE] p-5 shadow-polaroid flex flex-col justify-between gap-4 ${
                    isCompleted
                      ? 'border-[#455342]/35 ring-1 ring-[#455342]/15'
                      : 'border-[#38271F]/14'
                  }`}
                >
                  <span
                    aria-hidden="true"
                    className={`absolute -top-2.5 left-7 w-14 h-3.5 -rotate-2 ${
                      isCompleted ? 'washi-tape-sage' : 'washi-tape-gold'
                    }`}
                  />

                  <div className="space-y-3">
                    {/* Meta badges */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span
                          className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold text-[#F4EBDD]"
                          style={{ backgroundColor: catMeta.accent }}
                        >
                          {catMeta.label}
                        </span>
                        <span
                          className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold"
                          style={{ backgroundColor: stMeta.bg, color: stMeta.color }}
                        >
                          {stMeta.label}
                        </span>
                      </div>

                      <span className="text-[11px] font-medium text-[#38271F]/60">
                        Oleh {entry.creatorName}
                      </span>
                    </div>

                    <div>
                      <h2 className="font-serif text-xl font-semibold text-[#38271F]">
                        {entry.title}
                      </h2>
                      {entry.targetDate && (
                        <p className="mt-0.5 text-xs font-medium text-[#743D4A] inline-flex items-center gap-1">
                          <CalendarHeart className="w-3.5 h-3.5" />
                          <span>Target: {entry.targetDate}</span>
                        </p>
                      )}
                      {entry.description && (
                        <p className="mt-2 text-sm text-[#38271F]/80 leading-relaxed whitespace-pre-line">
                          {entry.description}
                        </p>
                      )}
                    </div>

                    {/* Completion Memory Card */}
                    {isCompleted && (entry.completionStory || entry.completedAt) && (
                      <div className="rounded-xl border border-[#455342]/25 bg-[#455342]/8 p-3.5 space-y-1.5">
                        <p className="text-[11px] font-semibold text-[#455342] uppercase tracking-wider flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Kenangan Yang Sudah Tercapai ♡</span>
                        </p>
                        {entry.completionStory && (
                          <p className="text-xs sm:text-sm text-[#38271F] leading-relaxed whitespace-pre-line">
                            {entry.completionStory}
                          </p>
                        )}
                      </div>
                    )}

                    {/* Attached Photos */}
                    {entry.photos.length > 0 && (
                      <div className="grid grid-cols-3 gap-2 pt-1">
                        {entry.photos.map((photoUrl, idx) => (
                          <button
                            key={`${photoUrl}-${idx}`}
                            type="button"
                            onClick={() => setLightboxUrl(photoUrl)}
                            className="aspect-square rounded-xl overflow-hidden border border-[#38271F]/14 bg-[#EAE0CF] cursor-pointer hover:opacity-90 transition-opacity"
                          >
                            <img
                              src={photoUrl}
                              alt={`${entry.title} foto ${idx + 1}`}
                              className="w-full h-full object-cover"
                              loading="lazy"
                            />
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Card Footer Actions */}
                  <div className="pt-3 border-t border-[#38271F]/10 flex flex-wrap items-center justify-between gap-2">
                    <span className="text-[11px] text-[#38271F]/50 tabular-nums">
                      {entry.createdAt
                        ? new Date(entry.createdAt).toLocaleDateString('id-ID', {
                            day: 'numeric',
                            month: 'short',
                            year: 'numeric',
                          })
                        : 'Baru dibuat'}
                    </span>

                    <div className="flex flex-wrap items-center gap-1.5">
                      {canEdit && !isCompleted && (
                        <button
                          type="button"
                          onClick={() => handleQuickComplete(entry)}
                          className="min-h-[38px] px-3 rounded-xl bg-[#455342]/12 text-[#455342] text-xs font-semibold inline-flex items-center gap-1 hover:bg-[#455342]/20 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Tandai Tercapai</span>
                        </button>
                      )}

                      {canEdit && (
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(entry)}
                          aria-label={`Edit ${entry.title}`}
                          className="min-h-[38px] px-3 rounded-xl border border-[#38271F]/18 bg-[#F4EBDD] text-[#38271F] text-xs font-semibold inline-flex items-center gap-1 hover:bg-[#EAE0CF] cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                      )}

                      {canDelete && (
                        confirmDeleteId === entry.id ? (
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleDelete(entry.id)}
                              className="min-h-[38px] px-3 rounded-xl bg-[#A6533B] text-[#F4EBDD] text-xs font-semibold cursor-pointer"
                            >
                              Ya, Hapus
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="min-h-[38px] px-2.5 rounded-xl border border-[#38271F]/20 text-xs cursor-pointer"
                            >
                              Batal
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(entry.id)}
                            aria-label={`Hapus ${entry.title}`}
                            className="min-h-[38px] px-2.5 rounded-xl text-xs font-semibold text-[#A6533B] hover:bg-[#A6533B]/10 inline-flex items-center gap-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </section>
        )}
      </div>

      {/* Create / Edit Modal */}
      {modalOpen && (
        <WishFormModal
          mode={editingEntry ? 'edit' : 'create'}
          initialEntry={editingEntry}
          defaultRole={coupleRole}
          onClose={() => {
            setModalOpen(false);
            setEditingEntry(null);
          }}
          onSubmit={async (payload) => {
            if (editingEntry) {
              await updateWishlistEntry(
                editingEntry.id,
                editingEntry.status,
                {
                  title: payload.title,
                  description: payload.description,
                  category: payload.category,
                  targetDate: payload.targetDate,
                  status: payload.status,
                  photos: payload.photos,
                  completionStory: payload.completionStory,
                  completedAt: editingEntry.completedAt,
                },
                coupleRole
              );
            } else {
              await createWishlistEntry({
                id: payload.id,
                title: payload.title,
                description: payload.description,
                category: payload.category,
                targetDate: payload.targetDate,
                status: payload.status,
                photos: payload.photos,
                completionStory: payload.completionStory,
                role: coupleRole,
                accessConfig,
              });
            }
          }}
        />
      )}

      {/* Simple Photo Lightbox */}
      {lightboxUrl && (
        <div
          className="fixed inset-0 z-50 bg-[#140D0A]/85 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          onClick={() => setLightboxUrl(null)}
        >
          <img
            src={lightboxUrl}
            alt="Foto Kenangan Wishlist"
            className="max-w-full max-h-[85dvh] rounded-2xl border-4 border-[#FBF6EE] shadow-2xl object-contain"
          />
        </div>
      )}
    </main>
  );
}
