import { motion, AnimatePresence } from 'motion/react';
import { Award, CheckCircle2, Lock, Sparkles, X } from 'lucide-react';
import { BotanicalFlowerSVG } from '../components/Flower';
import { FLOWERS_DATA } from '../data/flowers';
import { useStore } from '../store/useStore';
import { isFlowerQuestComplete } from '../utils/storage';
import { EASE_OUT_EXPO } from '../utils/animation';

export function QuestsModal() {
  const questModalOpen = useStore((s) => s.questModalOpen);
  const setQuestModalOpen = useStore((s) => s.setQuestModalOpen);
  const collectedFlowers = useStore((s) => s.collectedFlowers);
  const claimReward = useStore((s) => s.claimReward);

  const complete = isFlowerQuestComplete(collectedFlowers);

  return (
    <AnimatePresence>
      {questModalOpen && (
        <motion.div
          key="quests-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setQuestModalOpen(false)}
          className="fixed inset-0 z-50 bg-[#38271F]/65 flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
        >
          <motion.section
            role="dialog"
            aria-modal="true"
            aria-labelledby="quests-modal-title"
            initial={{ opacity: 0, y: 20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.96 }}
            transition={{ duration: 0.28, ease: EASE_OUT_EXPO }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-2xl bg-[#FBF6EE] border border-[#38271F]/20 rounded-2xl shadow-2xl p-6 sm:p-8 my-auto"
          >
            <button
              type="button"
              onClick={() => setQuestModalOpen(false)}
              aria-label="Tutup Misi Rahasia"
              className="absolute top-4 right-4 min-w-[44px] min-h-[44px] rounded-full bg-[#F4EBDD] border border-[#38271F]/15 text-[#38271F] hover:bg-[#EAE0CF] flex items-center justify-center cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="pr-10">
              <p className="text-xs tracking-widest uppercase text-[#743D4A] font-medium flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#A6533B]" />
                <span>Secret Quest</span>
              </p>
              <h2
                id="quests-modal-title"
                className="mt-1 font-serif text-2xl sm:text-3xl font-semibold text-[#38271F]"
              >
                Misi Rahasia Dunia Kecil
              </h2>
              <p className="mt-1.5 text-sm text-[#38271F]/72">
                Kamu menemukan pintu rahasia lewat Mini Oktaf! Selesaikan misi yang tersedia untuk membuka halaman hadiah terakhir.
              </p>
            </div>

            <div className="mt-6 space-y-4">
              {/* Quest 1: The Lost Flowers (Fully Functional) */}
              <div className="bg-[#F4EBDD]/75 border border-[#455342]/25 rounded-xl p-4 sm:p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="text-xs font-medium text-[#455342]">
                      Quest 1 · Aktif
                    </span>
                    <h3 className="font-serif text-xl font-semibold text-[#38271F]">
                      The Lost Flowers
                    </h3>
                  </div>
                  <span className="text-sm font-semibold text-[#A6533B] tabular-nums">
                    {collectedFlowers.length}/{FLOWERS_DATA.length} Flowers
                  </span>
                </div>

                <p className="mt-1.5 text-xs sm:text-sm text-[#38271F]/75">
                  Temukan tujuh bunga botani unik yang terselip di berbagai sudut halaman website ini.
                </p>

                {/* Progress bar */}
                <div className="mt-3 h-2 w-full rounded-full bg-[#38271F]/10 overflow-hidden">
                  <div
                    className="h-full bg-[#455342] transition-all duration-500"
                    style={{
                      width: `${(collectedFlowers.length / FLOWERS_DATA.length) * 100}%`,
                    }}
                  />
                </div>

                {/* 7 Flower Checklist */}
                <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {FLOWERS_DATA.map((flower) => {
                    const found = collectedFlowers.includes(flower.id);
                    return (
                      <div
                        key={flower.id}
                        className={`flex items-center gap-3 rounded-lg px-3 py-2 border transition-colors ${
                          found
                            ? 'bg-[#FBF6EE] border-[#455342]/30'
                            : 'bg-[#FBF6EE]/45 border-[#38271F]/10'
                        }`}
                      >
                        <div className={found ? 'opacity-100' : 'opacity-30 grayscale'}>
                          <BotanicalFlowerSVG species={flower.species} className="w-9 h-9" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-semibold text-[#38271F] flex items-center gap-1.5">
                            <span className="truncate">{flower.indonesianName}</span>
                            {found && (
                              <CheckCircle2 className="w-3.5 h-3.5 text-[#455342] shrink-0" />
                            )}
                          </p>
                          <p className="text-[11px] text-[#38271F]/65 line-clamp-1">
                            {found ? 'Sudah ditemukan!' : flower.locationHint}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {complete && (
                  <div className="mt-4 pt-4 border-t border-[#455342]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <p className="text-sm font-medium text-[#455342]">
                      Semua 7 bunga sudah terkumpul! Halaman rahasia siap dibuka.
                    </p>
                    <button
                      type="button"
                      onClick={claimReward}
                      className="min-h-[44px] px-5 py-2 rounded-xl bg-[#A6533B] text-[#F4EBDD] text-xs font-semibold hover:bg-[#8e442f] transition-colors inline-flex items-center justify-center gap-2 cursor-pointer shrink-0"
                    >
                      <Award className="w-4 h-4" />
                      <span>Buka Hadiah Terakhir</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Quest 2 & Quest 3: Locked / Coming Soon */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="bg-[#EFE5D6]/60 border border-[#38271F]/12 rounded-xl p-4 opacity-80">
                  <div className="flex items-center justify-between text-xs text-[#38271F]/60">
                    <span>Quest 2</span>
                    <span className="inline-flex items-center gap-1 font-medium">
                      <Lock className="w-3 h-3" />
                      Coming Soon
                    </span>
                  </div>
                  <h3 className="mt-1 font-serif text-lg font-semibold text-[#38271F]/75">
                    How Well?
                  </h3>
                  <p className="mt-1 text-xs text-[#38271F]/60">
                    Misi kecil berikutnya akan segera hadir di pembaruan mendatang.
                  </p>
                </div>

                <div className="bg-[#EFE5D6]/60 border border-[#38271F]/12 rounded-xl p-4 opacity-80">
                  <div className="flex items-center justify-between text-xs text-[#38271F]/60">
                    <span>Quest 3</span>
                    <span className="inline-flex items-center gap-1 font-medium">
                      <Lock className="w-3 h-3" />
                      Coming Soon
                    </span>
                  </div>
                  <h3 className="mt-1 font-serif text-lg font-semibold text-[#38271F]/75">
                    Memories
                  </h3>
                  <p className="mt-1 text-xs text-[#38271F]/60">
                    Bab rahasia tambahan sedang disiapkan di balik sampul jurnal.
                  </p>
                </div>
              </div>
            </div>
          </motion.section>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
