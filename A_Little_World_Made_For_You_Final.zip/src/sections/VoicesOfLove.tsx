import { useEffect, useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { Flower2, HeartHandshake } from 'lucide-react';
import { VoiceCard } from '../components/voices/VoiceCard';
import { VoiceFlowerSVG } from '../components/voices/VoiceFlowerSVG';
import { useContentStore } from '../store/useContentStore';
import { useStore } from '../store/useStore';
import { normalizeVoicesOrder } from '../utils/adminContent';
import { EASE_OUT_EXPO } from '../utils/animation';

export function VoicesOfLove() {
  const voicesRaw = useContentStore((s) => s.voices);
  const navigateTo = useStore((s) => s.navigateTo);

  const [activeVoiceId, setActiveVoiceId] = useState<string | null>(null);

  const voices = useMemo(() => normalizeVoicesOrder(voicesRaw), [voicesRaw]);

  useEffect(() => {
    return () => {
      setActiveVoiceId(null);
    };
  }, []);

  return (
    <main
      className="paper-canvas relative min-h-[calc(100dvh-3.5rem)] w-full px-4 sm:px-8 pt-8 pb-28 overflow-x-hidden"
      data-testid="voices-of-love-section"
    >
      <div className="max-w-5xl mx-auto">
        {/* Botanical Garden Header */}
        <motion.header
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: EASE_OUT_EXPO }}
          className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#38271F]/12"
        >
          <div>
            <p className="text-xs tracking-widest uppercase text-[#743D4A] font-medium">
              05 · Taman Suara Sahabat
            </p>
            <h1 className="mt-1 font-serif text-3xl sm:text-4xl font-semibold text-[#38271F]">
              Voices of Love ♡
            </h1>
            <p className="mt-1.5 text-sm sm:text-base text-[#38271F]/75 max-w-2xl">
              A collection of little voices from people who make your world brighter.
            </p>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <div className="postage-stamp px-3 py-1.5 text-[10px] tracking-widest uppercase text-[#455342] font-semibold">
              {voices.length} Bunga Suara
            </div>
          </div>
        </motion.header>

        {/* Empty Garden State when no friend MP3 recordings have been uploaded yet */}
        {voices.length === 0 ? (
          <motion.section
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: EASE_OUT_EXPO }}
            className="mt-10 rounded-2xl border border-dashed border-[#38271F]/22 bg-[#FBF6EE]/90 p-8 sm:p-10 text-center max-w-2xl mx-auto shadow-polaroid"
          >
            <div className="flex items-center justify-center gap-3 mb-4">
              <VoiceFlowerSVG flowerType="sakura" className="w-12 h-12" />
              <VoiceFlowerSVG flowerType="sunflower" className="w-14 h-14" />
              <VoiceFlowerSVG flowerType="lavender" className="w-12 h-12" />
            </div>
            <h2 className="font-serif text-2xl font-semibold text-[#38271F]">
              Taman Bunga Suara Menanti Rekaman Pertama
            </h2>
            <p className="mt-2.5 text-sm text-[#38271F]/72 leading-relaxed">
              Belum ada pesan suara sahabat yang ditambahkan. Oktaf dapat mengunggah file MP3
              rekaman ucapan langsung dari sahabat Wulan lewat{' '}
              <strong className="font-semibold text-[#743D4A]">My Little Control Room</strong>{' '}
              (<code className="text-xs px-1.5 py-0.5 rounded bg-[#EAE0CF]">/admin</code>), dan setiap
              kartu akan mekar di halaman ini.
            </p>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => navigateTo('hub')}
                className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#38271F] text-[#F4EBDD] text-xs font-semibold hover:bg-[#4e382d] transition-colors inline-flex items-center gap-2 cursor-pointer"
              >
                <Flower2 className="w-4 h-4 text-[#E8BFC5]" />
                <span>Kembali ke Beranda</span>
              </button>
              <a
                href="/admin"
                onClick={(e) => {
                  e.preventDefault();
                  window.history.pushState(null, '', '/admin');
                  window.dispatchEvent(new PopStateEvent('popstate'));
                }}
                className="min-h-[44px] px-5 py-2.5 rounded-xl border border-[#38271F]/20 text-[#38271F] text-xs font-semibold hover:bg-[#EAE0CF] transition-colors inline-flex items-center gap-2"
              >
                <HeartHandshake className="w-4 h-4 text-[#A6533B]" />
                <span>Tambah Rekaman via Control Room</span>
              </a>
            </div>
          </motion.section>
        ) : (
          <section
            aria-label="Daftar ucapan suara sahabat"
            className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            {voices.map((entry, idx) => (
              <VoiceCard
                key={entry.id}
                entry={entry}
                index={idx}
                isActive={activeVoiceId === entry.id}
                onRequestPlay={(id) => setActiveVoiceId(id)}
                onPlaybackEndedOrPaused={(id) =>
                  setActiveVoiceId((current) => (current === id ? null : current))
                }
              />
            ))}
          </section>
        )}
      </div>
    </main>
  );
}
