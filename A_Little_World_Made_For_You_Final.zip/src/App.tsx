import { useEffect, useState } from 'react';
import { MiniOktafCharacter } from './components/MiniOktafCharacter';
import { Navigation } from './components/Navigation';
import { VinylPlayer } from './components/vinyl/VinylPlayer';
import { FirebaseProvider } from './lib/FirebaseProvider';
import { AdminDashboard } from './sections/AdminDashboard';
import { BirthdayLetters } from './sections/BirthdayLetters';
import { BirthdayWelcome } from './sections/BirthdayWelcome';
import { FinalReward } from './sections/FinalReward';
import { FutureWishlist } from './sections/FutureWishlist';
import { Hub } from './sections/Hub';
import { OurStory } from './sections/OurStory';
import { OurWorld } from './sections/OurWorld';
import { PasswordGate } from './sections/PasswordGate';
import { QuestsModal } from './sections/Quests';
import { VideoGreeting } from './sections/VideoGreeting';
import { VoicesOfLove } from './sections/VoicesOfLove';
import { useContentStore } from './store/useContentStore';
import { useStore } from './store/useStore';

function isAdminRoute(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.location.pathname === '/admin' ||
    window.location.pathname.startsWith('/admin/') ||
    window.location.hash === '#/admin'
  );
}

function AppShell() {
  const currentSection = useStore((s) => s.currentSection);
  const isUnlocked = useStore((s) => s.isUnlocked);
  const hydrateFromServer = useContentStore((s) => s.hydrateFromServer);

  const [inAdminRoute, setInAdminRoute] = useState<boolean>(() => isAdminRoute());

  useEffect(() => {
    hydrateFromServer();
  }, [hydrateFromServer]);

  useEffect(() => {
    const syncRoute = () => setInAdminRoute(isAdminRoute());
    window.addEventListener('popstate', syncRoute);
    window.addEventListener('hashchange', syncRoute);
    return () => {
      window.removeEventListener('popstate', syncRoute);
      window.removeEventListener('hashchange', syncRoute);
    };
  }, []);

  const handleExitAdmin = () => {
    window.history.pushState(null, '', '/');
    setInAdminRoute(false);
    hydrateFromServer();
  };

  if (inAdminRoute) {
    return <AdminDashboard onExitToPublic={handleExitAdmin} />;
  }

  const showFloatingCompanions =
    isUnlocked && currentSection !== 'password' && currentSection !== 'welcome';

  return (
    <div
      className="min-h-[100dvh] w-full bg-[#F4EBDD] text-[#38271F]"
      data-section={currentSection}
    >
      <Navigation />

      <div key={currentSection}>
        {currentSection === 'password' && <PasswordGate />}
        {currentSection === 'welcome' && <BirthdayWelcome />}
        {currentSection === 'hub' && <Hub />}
        {currentSection === 'story' && <OurStory />}
        {currentSection === 'world' && <OurWorld />}
        {currentSection === 'letters' && <BirthdayLetters />}
        {currentSection === 'video' && <VideoGreeting />}
        {currentSection === 'voices' && <VoicesOfLove />}
        {currentSection === 'wishlist' && <FutureWishlist />}
        {currentSection === 'reward' && <FinalReward />}
      </div>

      {/* Persistent floating Vinyl Player (bottom-left) & Mini Oktaf (bottom-right) */}
      {showFloatingCompanions && <VinylPlayer />}
      {showFloatingCompanions && <MiniOktafCharacter mode="floating" />}

      <QuestsModal />
    </div>
  );
}

export default function App() {
  return (
    <FirebaseProvider>
      <AppShell />
    </FirebaseProvider>
  );
}
