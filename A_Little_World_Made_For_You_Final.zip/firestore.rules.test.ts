import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const RULES_PATH = path.resolve(process.cwd(), 'firestore.rules');
const BLUEPRINT_PATH = path.resolve(process.cwd(), 'firebase-blueprint.json');
const rulesText = fs.readFileSync(RULES_PATH, 'utf8');
const blueprint = JSON.parse(fs.readFileSync(BLUEPRINT_PATH, 'utf8'));

test('firestore.rules covers every collection defined in firebase-blueprint.json', () => {
  assert.ok(rulesText.includes("rules_version = '2';"));
  assert.ok(rulesText.includes('match /{document=**} {\n      allow read, write: if false;\n    }'));

  const blueprintCollections = Object.keys(blueprint.firestore);
  for (const colPath of blueprintCollections) {
    assert.ok(
      rulesText.includes(`match ${colPath}`),
      `Missing match block for blueprint path: ${colPath}`
    );
  }
});

test('firestore.rules enforces email_verified, request.time, ID validation, and no get/exists inside allow list', () => {
  assert.ok(rulesText.includes('request.auth.token.email_verified == true'));
  assert.ok(rulesText.includes('request.time'));
  assert.ok(rulesText.includes("id.matches('^[a-zA-Z0-9_\\\\-]+$')"));

  // Check allow list lines do not call get( or exists(
  const listMatches = rulesText.match(/allow list:[\s\S]*?;/g) || [];
  assert.ok(listMatches.length >= 6);
  for (const rule of listMatches) {
    assert.equal(rule.includes('get('), false, `allow list must not use get(): ${rule}`);
    assert.equal(rule.includes('exists('), false, `allow list must not use exists(): ${rule}`);
  }
});

test('wishlist security guards block unauthenticated access, non-couple users, shadow fields, and terminal regression', () => {
  const wishlistSectionStart = rulesText.indexOf('match /wishlist/{wishId}');
  assert.ok(wishlistSectionStart > 0);
  const wishlistSection = rulesText.slice(wishlistSectionStart);

  // Must never allow unauthenticated reads or list
  assert.equal(wishlistSection.includes('allow get: if true'), false);
  assert.equal(wishlistSection.includes('allow list: if true'), false);
  // Must validate allowedEmails & creatorUid & status lock
  assert.ok(wishlistSection.includes('isValidWishlistEntry(incoming(), wishId)'));
  assert.ok(wishlistSection.includes('incoming().creatorUid == request.auth.uid'));
  assert.ok(wishlistSection.includes("existing().status == 'completed'"));
  assert.ok(wishlistSection.includes("incoming().status == 'completed'"));
  assert.ok(wishlistSection.includes('isCoupleMember()'));
});
